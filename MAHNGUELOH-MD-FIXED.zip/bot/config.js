'use strict'

// ─────────────────────────────────────────────────────────────────────────────
//  MAHNGUELOH-MD — Configuration
//  All values fall back to environment variables so the bot is fully
//  Railway / Pterodactyl / VPS compatible without editing this file.
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
    // ── Identity ──────────────────────────────────────────────────────────────
    botName:     process.env.BOT_NAME     || 'MAHNGUELOH-MD',
    ownerName:   process.env.OWNER_NAME   || 'MAHNGUELOH',
    ownerNumber: process.env.OWNER_NUMBER || '254732223354',  // digits + country code, no +
    prefix:      process.env.PREFIX       || '.',

    // ── Mode: 'public' (everyone) | 'private' (owner only) ───────────────────
    mode: process.env.MODE || 'public',

    // ── AI ────────────────────────────────────────────────────────────────────
    aiEnabled:    process.env.AI_ENABLED   !== 'false',
    openaiApiKey: process.env.OPENAI_API_KEY  || '',
    geminiApiKey: process.env.GEMINI_API_KEY  || '',

    // ── Limits ────────────────────────────────────────────────────────────────
    maxDownloadSize: parseInt(process.env.MAX_DOWNLOAD_MB || '80'),   // MB
    commandCooldownMs: parseInt(process.env.COOLDOWN_MS  || '3000'),  // per user

    // ── Optional sudo numbers (extra owners) — comma-separated ───────────────
    sudoNumbers: (process.env.SUDO_NUMBERS || '').split(',').map(n => n.trim()).filter(Boolean),

    // ── Timezone for menu clock ───────────────────────────────────────────────
    timezone: process.env.TIMEZONE || 'Africa/Nairobi',

    // ── Version ───────────────────────────────────────────────────────────────
    version: '3.1.0',
}
