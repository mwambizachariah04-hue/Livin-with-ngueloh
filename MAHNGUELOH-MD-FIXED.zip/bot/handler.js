'use strict'
const config = require('./config')
const fmt    = require('./lib/format')
const { getBody, getSender, getFrom, isGroup, isOwner, isPublicMode, getCachedGroupMeta, isBotAdmin } = require('./lib/utils')

const { sendMenu }              = require('./plugins/menu')
const { makeSticker }           = require('./plugins/sticker')
const { handleGroupCmd, isBanned, handleGroupEvents } = require('./plugins/groups')
const { antiLinkCheck, antiSpamCheck, antiStickerCheck, antiVoiceNoteCheck, antiBugCheck, antiGroupMentionCheck } = require('./plugins/antiSpam')
const { handleAdult }           = require('./plugins/adult')
const { downloadMedia }         = require('./plugins/downloader')
const { aiReply }               = require('./plugins/aiChat')
const { handleOwnerCmd, badWords, ignoredNumbers, runtimeSettings } = require('./plugins/ownerCmds')
const { handleSports }          = require('./plugins/sports')
const { getBible, getQuran }    = require('./plugins/religion')
const { getLyrics, getIMDB, getYTS } = require('./plugins/search')
const { getWallpaper, getRemini } = require('./plugins/image')
const { handleCustomCmdBuilder, checkCustomCmd } = require('./plugins/customCmds')
const { getSettings, setSetting } = require('./plugins/groupSettings')

const spamMap    = new Map()
const cooldownMap = new Map()

// Per-user command cooldown — prevents flooding
function checkCooldown(sender, cmd) {
    const cd  = config.commandCooldownMs || 3000
    const key = `${sender}:${cmd}`
    const last = cooldownMap.get(key) || 0
    const now  = Date.now()
    if (now - last < cd) return Math.ceil((cd - (now - last)) / 1000)
    cooldownMap.set(key, now)
    // Auto-clean every 500 entries to prevent memory leak
    if (cooldownMap.size > 500) {
        const cutoff = now - cd * 10
        for (const [k, v] of cooldownMap) { if (v < cutoff) cooldownMap.delete(k) }
    }
    return 0
}

// ── Fun data ──────────────────────────────────────────────────────────────────
const facts  = ["🌍 A day on Venus is longer than a year on Venus.","🐙 Octopuses have three hearts and blue blood.","🍯 Honey never expires — 3000-year-old honey was still edible.","🌙 The moon moves away from Earth at 3.8cm per year.","🐘 Elephants are the only animals that can't jump.","⚡ Lightning strikes Earth 100 times every second.","🧠 Your brain generates about 20 watts of electricity.","🦈 Sharks are older than trees.","🐝 Bees can recognise human faces.","🌊 The ocean covers 71% of Earth's surface."]
const jokes  = ["😂 Why don't scientists trust atoms?\nBecause they make up everything!","😂 Why did the scarecrow win an award?\nBecause he was outstanding in his field!","😂 What do you call fake spaghetti?\nAn impasta!","😂 What do you call cheese that isn't yours?\nNacho cheese!","😂 I told my wife she should embrace her mistakes.\nShe gave me a hug.","😂 Why don't eggs tell jokes?\nThey'd crack each other up!","😂 I'm reading a book about anti-gravity. It's impossible to put down!","😂 What do you call a fish without eyes? A fsh!"]
const quotes = ["💬 _\"The only way to do great work is to love what you do.\"_ — Steve Jobs","💬 _\"In the middle of every difficulty lies opportunity.\"_ — Albert Einstein","💬 _\"It does not matter how slowly you go as long as you do not stop.\"_ — Confucius","💬 _\"The future belongs to those who believe in the beauty of their dreams.\"_ — Eleanor Roosevelt","💬 _\"Success is not final, failure is not fatal.\"_ — Churchill","💬 _\"Be yourself; everyone else is already taken.\"_ — Oscar Wilde","💬 _\"Two things are infinite: the universe and human stupidity.\"_ — Einstein"]
const trivia = [{q:"What is the capital of Australia?",a:"Canberra"},{q:"How many bones in the human body?",a:"206"},{q:"Largest planet in our solar system?",a:"Jupiter"},{q:"WW2 ended in what year?",a:"1945"},{q:"Chemical symbol for gold?",a:"Au"},{q:"Fastest land animal?",a:"Cheetah"},{q:"Who painted the Mona Lisa?",a:"Leonardo da Vinci"},{q:"How many sides does a hexagon have?",a:"6"},{q:"What is the speed of light (approx)?",a:"299,792,458 m/s"},{q:"Which element has atomic number 1?",a:"Hydrogen"}]
const truthQs = ["🤔 What is the most embarrassing thing you've ever done?","🤔 Have you ever lied to get out of trouble?","🤔 What's your biggest fear?","🤔 Have you ever had a crush on someone in this group?","🤔 What is your biggest regret?","🤔 Have you ever cheated on a test?","🤔 What's the most childish thing you still do?","🤔 Have you ever stalked someone's social media?"]
const dares  = ["🎯 Send a voice note singing any song!","🎯 Change your profile picture to a funny face for 1 hour!","🎯 Tag 3 people and say something nice about each!","🎯 Send the last photo in your gallery!","🎯 Write a poem about the person above you!","🎯 Call someone in the group right now!","🎯 Send a selfie right now!","🎯 Share your most embarrassing autocorrect fail!"]
function rand(arr) { return arr[Math.floor(Math.random() * arr.length)] }

// ── Command sets ──────────────────────────────────────────────────────────────
const sportsCmds = new Set(['epl','eplmatches','eplstandings','eplscorers','eplupcoming','bundesliga','bundesligamatches','bundesligastandings','bundesligascorers','bundesligaupcoming','laliga','laligamatches','laligastandings','laligascorers','laligaupcoming','seriea','serieamatches','serieastandings','serieascorers','serieaupcoming','ligue1','ligue1matches','ligue1standings','ligue1scorers','ligue1upcoming','cl','clmatches','clstandings','clscorers','clupcoming','eflmatches','eflstandings','eflscorers','eflupcoming','elmatches','elstandings','elscorers','elupcoming','wcmatches','wcstandings','wcscorers','wcupcoming','wrestlingevents','wwenews','wweschedule'])

const downloadCmds = new Set([
    // Music
    'play','song','song2','music','mp3',
    // YouTube
    'ytmp3','ytmp4','yt','yta','ytv','tomp3','toaudio','tovideo','download',
    // Social
    'tiktok','tt','tkvid','tiktokaudio','tkaudio','ttaudio',
    'ig','instagram','insta',
    'twitter','x','tweet',
    'facebook','fb','fbvid',
    // Extra
    'spotify','sp','spdl',
    'mediafire','mf','mfdl',
    'video',
])

const groupCmds = new Set(['kick','add','promote','demote','mute','unmute','kickall','ban','unban','antilink','antispam','antisticker','antivoicenote','antibug','antiremove','antigroupmention','welcome','goodbye','setgroupname','setdesc','resetlink','setppgroup','getgrouppp','invite','link','tagall','tagadmin','hidetag','admins','totalmembers','members','poll','getsettings','debugadmin','announcements','open','close'])

const adultCmds = new Set(['hentai','naughty','lewdwaifu','nsfw','lewdanime','rule34','danbooru','xbooru'])

const ownerOnlyCmds = new Set([
    'setbotname','setownername','setownernumber','setprefix','setbio','setprofilepic',
    'restart','block','unblock','unblockall','listblocked','join','leave','groupid',
    'hostip','disk','addsudo','delsudo','listsudo',
    'addbadword','deletebadword','listbadword',
    'addignorelist','delignorelist','listignorelist',
    'warn','resetwarn','listwarn',
    'delete','react','online','lastseen','alwaysonline','autoread','readreceipts',
    'autotype','tostatus','toviewonce','vv2','deljunk',
    'setgroupname','setdesc','resetlink','setppgroup','getgrouppp',
    'modestatus','runeval',
    'addcmd','delcmd','editcmd','listcmd','listcmds','mycmds','cmdinfo',
    'autoviewstatus','autoreactstatus','autosavestatus','autoreact',
    'anticall','antidelete','antiedit','antiviewonce',
    'autobio','autoblock','autorecord','autorecordtyping',
    'statusdelay','statussettings','setwatermark','setfont',
    'setcontextlink','setstatusemoji','setstickerauthor','setstickerpackname',
    'settimezone','setmenu','setmenuimage','setwelcome','setgoodbye',
    'showwelcome','showgoodbye','testwelcome','testgoodbye','delwelcome','delgoodbye',
    'resetsetting','setanticallmsg','showanticallmsg','delanticallmsg','testanticallmsg',
    'addcountrycode','delcountrycode','listcountrycode',
    'aza','resetaza','setaza','ppprivacy','gcaddprivacy','dlvo','update',
    'allgroups','mode','chatbot','botstatus','runtime','bancheck',
    'broadcast',
    // NOTE: getpp, getabout, device are intentionally PUBLIC — handled in switch, not here
])

const alwaysPublic = new Set(['ping','ping2','myid','whoami','debugowner'])

const startTime = Date.now()

// ─────────────────────────────────────────────────────────────────────────────
async function handleMessage(sock, msg) {
    try {
        const body      = getBody(msg)
        const botJid    = sock.user?.id || ''
        const sender    = getSender(msg, botJid)
        const from      = getFrom(msg)
        const inGroup   = isGroup(from)
        const owner     = isOwner(sender, botJid, msg.key?.fromMe)
        const publicMode = isPublicMode()
        const prefix    = config.prefix

        // Banned user — silently delete their message
        if (isBanned(sender)) {
            try { await sock.sendMessage(from, { delete: msg.key }) } catch {}
            return
        }

        // Ignored numbers
        if (!owner && ignoredNumbers.includes(sender.replace('@s.whatsapp.net','').replace(/[^0-9]/g,''))) return

        // ── Group protection ─────────────────────────────────────────────────
        if (inGroup) {
            if (await antiBugCheck(sock, msg, from, sender, owner)) return
            if (await antiLinkCheck(sock, msg, from, sender, owner)) return
            if (await antiStickerCheck(sock, msg, from, sender, owner)) return
            if (await antiVoiceNoteCheck(sock, msg, from, sender, owner)) return
            if (await antiGroupMentionCheck(sock, msg, from, sender, owner)) return
            if (await antiSpamCheck(sock, msg, from, sender, spamMap)) return
            if (body && badWords.length) {
                const lb = body.toLowerCase()
                if (badWords.some(w => lb.includes(w))) {
                    try { await sock.sendMessage(from, { delete: msg.key }) } catch {}
                    await sock.sendMessage(from, {
                        text: fmt.box('BAD LANGUAGE', [`⚠️ @${sender.split('@')[0]} — offensive language is *not allowed*`]),
                        mentions: [sender]
                    })
                    return
                }
            }
        }

        if (!body) return

        const isCmd = body.startsWith(prefix)
        const cmd   = isCmd ? body.slice(prefix.length).trim().split(/\s+/)[0].toLowerCase() : ''
        const args  = isCmd ? body.slice(prefix.length + cmd.length).trim().split(/\s+/).filter(Boolean) : []
        const q     = args.join(' ').trim()

        // ── Non-command: AI auto-reply in DM ─────────────────────────────────
        if (!isCmd) {
            if (!inGroup && config.aiEnabled && (owner || publicMode)) {
                await aiReply(sock, from, body, msg)
            }
            return
        }

        // ── Private mode guard ────────────────────────────────────────────────
        if (!publicMode && !owner && !alwaysPublic.has(cmd)) {
            return sock.sendMessage(from, {
                text: fmt.box('PRIVATE MODE', [
                    `🔒 *${config.botName}* is currently in *Private Mode*`,
                    ``,
                    `Only the owner can use commands right now`,
                    ``,
                    `📱 Contact: wa.me/${config.ownerNumber}`,
                ])
            }, { quoted: msg })
        }

        // ── Per-user cooldown (skip for owner) ───────────────────────────────
        if (!owner && isCmd && cmd) {
            const wait = checkCooldown(sender, cmd)
            if (wait > 0) {
                await sock.sendMessage(from, {
                    text: fmt.box('⏱ SLOW DOWN', [
                        `Please wait *${wait}s* before using *${prefix}${cmd}* again`,
                        `_This prevents command flooding_`,
                    ])
                }, { quoted: msg })
                return
            }
        }

        // ── Custom commands ───────────────────────────────────────────────────
        const customHandled = await checkCustomCmd(sock, from, cmd, msg, prefix)
        if (customHandled) return

        // ── Owner-only guard ──────────────────────────────────────────────────
        if (ownerOnlyCmds.has(cmd) && !owner) {
            return sock.sendMessage(from, { text: fmt.permOwner() }, { quoted: msg })
        }

        // ── Sports ────────────────────────────────────────────────────────────
        if (sportsCmds.has(cmd)) {
            await fmt.react(sock, msg, '⚡')
            return handleSports(sock, from, cmd, msg)
        }

        // ── Downloads ─────────────────────────────────────────────────────────
        if (downloadCmds.has(cmd)) {
            if (!q) return sock.sendMessage(from, { text: fmt.usage(cmd, '<search / URL>') }, { quoted: msg })
            return downloadMedia(sock, from, cmd, q, msg)
        }

        // ── Group commands ────────────────────────────────────────────────────
        if (groupCmds.has(cmd)) {
            if (!inGroup) return sock.sendMessage(from, { text: fmt.permGroup() }, { quoted: msg })
            return handleGroupCmd(sock, msg, from, sender, cmd, args, owner)
        }

        // ── Adult commands ────────────────────────────────────────────────────
        if (adultCmds.has(cmd)) {
            if (!inGroup && !owner) return  // only in groups or for owner in DM
            return handleAdult(sock, from, cmd, q, msg)
        }

        // ── Typing indicator for ALL commands — makes bot feel instant ────────
        try { await sock.sendPresenceUpdate('composing', from) } catch {}

        switch (cmd) {

            // ════ MENU ════════════════════════════════════════════════════════
            case 'menu': case 'help':
                await sendMenu(sock, from, sender, msg)
                break

            // ════ PING ════════════════════════════════════════════════════════
            case 'ping': case 'ping2': {
                const start = Date.now()
                await sock.sendMessage(from, { text: fmt.box('PING', ['🏓 Testing response time...']) }, { quoted: msg })
                const ms = Date.now() - start
                await sock.sendMessage(from, {
                    text: fmt.box('PONG', [
                        `✅ Bot is *online* and responding`,
                        ``,
                        `⚡ *Response time:* ${ms}ms`,
                        `🌐 *Mode:* ${(config.mode || 'public').toUpperCase()}`,
                        `🤖 *AI:* ${config.aiEnabled !== false ? 'ON' : 'OFF'}`,
                    ])
                })
                break
            }

            // ════ OWNER INFO ══════════════════════════════════════════════════
            case 'owner':
                await sock.sendMessage(from, {
                    text: fmt.box('OWNER INFO', [
                        `👤 *Name:*   ${config.ownerName}`,
                        `📱 *Number:* wa.me/${config.ownerNumber}`,
                        `🤖 *Bot:*    ${config.botName}`,
                    ])
                }, { quoted: msg })
                break

            // ════ RUNTIME ═════════════════════════════════════════════════════
            case 'runtime': case 'uptime': {
                const up  = Date.now() - startTime
                const d   = Math.floor(up / 86400000)
                const h   = Math.floor((up % 86400000) / 3600000)
                const m2  = Math.floor((up % 3600000) / 60000)
                const s2  = Math.floor((up % 60000) / 1000)
                await sock.sendMessage(from, {
                    text: fmt.box('RUNTIME', [
                        `⏱ *Uptime:* ${d}d ${h}h ${m2}m ${s2}s`,
                        `🚀 *Bot:* ${config.botName}`,
                        `🌐 *Mode:* ${(config.mode || 'public').toUpperCase()}`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ BOT STATUS ══════════════════════════════════════════════════
            case 'botstatus': {
                const os = require('os')
                const t  = os.totalmem(), u = t - os.freemem()
                const pct = Math.round((u / t) * 100)
                const bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10))
                await sock.sendMessage(from, {
                    text: fmt.box('BOT STATUS', [
                        `✅ *Status:* Online`,
                        `🌐 *Mode:* ${(config.mode || 'public').toUpperCase()}`,
                        `🤖 *AI:* ${config.aiEnabled !== false ? 'ON' : 'OFF'}`,
                        `👁️ *Auto-view status:* ${runtimeSettings.autoviewstatus ? 'ON' : 'OFF'}`,
                        `📵 *Anti-call:* ${runtimeSettings.anticall ? 'ON' : 'OFF'}`,
                        `💾 *RAM:* ${Math.round(u / 1024 / 1024)}MB / ${(t / 1024 / 1024 / 1024).toFixed(1)}GB [${bar}] ${pct}%`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ MODE ════════════════════════════════════════════════════════
            case 'mode': {
                const newMode = q.toLowerCase()
                if (!['public', 'private'].includes(newMode)) {
                    return sock.sendMessage(from, {
                        text: fmt.box('MODE', [
                            `⚙️ *Current mode:* ${(config.mode || 'public').toUpperCase()}`,
                            ``,
                            `Usage: *${prefix}mode public* OR *${prefix}mode private*`,
                        ])
                    }, { quoted: msg })
                }
                config.mode = newMode
                await sock.sendMessage(from, {
                    text: fmt.box('MODE CHANGED', [
                        `✅ Mode → *${newMode.toUpperCase()}*`,
                        newMode === 'private' ? `🔒 Only you can use commands` : `🌐 Everyone can use commands`,
                    ])
                }, { quoted: msg })
                break
            }

            case 'modestatus':
                await sock.sendMessage(from, {
                    text: fmt.box('MODE STATUS', [`📊 Current mode: *${(config.mode || 'public').toUpperCase()}*`])
                }, { quoted: msg })
                break

            // ════ CHATBOT ═════════════════════════════════════════════════════
            case 'chatbot': {
                config.aiEnabled = !config.aiEnabled
                await sock.sendMessage(from, {
                    text: fmt.box('CHATBOT', [
                        `${config.aiEnabled ? '🟢' : '🔴'} AI chatbot is now *${config.aiEnabled ? 'ENABLED' : 'DISABLED'}*`,
                        config.aiEnabled ? `_Bot will respond to DM messages with AI_` : `_Bot will no longer auto-reply in DMs_`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ MY ID / WHO AM I ════════════════════════════════════════════
            case 'myid': case 'whoami': case 'userid': {
                const num = sender.split('@')[0]
                await sock.sendMessage(from, {
                    text: fmt.box('YOUR INFO', [
                        `📱 *Number:* ${num}`,
                        `🆔 *JID:* ${sender}`,
                        `👑 *Owner:* ${owner ? 'Yes ✅' : 'No'}`,
                        `🌐 *Source:* ${inGroup ? 'Group' : 'Private Chat'}`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ TIME ════════════════════════════════════════════════════════
            case 'time': case 'date': {
                const now = new Date()
                const nairobi = now.toLocaleString('en-KE', { timeZone: 'Africa/Nairobi', dateStyle: 'full', timeStyle: 'medium' })
                await sock.sendMessage(from, {
                    text: fmt.box('DATE & TIME', [
                        `🗓️ *Nairobi:* ${nairobi}`,
                        `🌍 *UTC:* ${now.toISOString().replace('T', ' ').slice(0, 19)}`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ REPO ════════════════════════════════════════════════════════
            case 'repo': case 'source':
                await sock.sendMessage(from, {
                    text: fmt.box('REPO', [
                        `🤖 *${config.botName}*`,
                        `👤 Owner: ${config.ownerName}`,
                        ``,
                        `_Custom WhatsApp bot built with Baileys_`,
                    ])
                }, { quoted: msg })
                break

            // ════ FEEDBACK ════════════════════════════════════════════════════
            case 'feedback': case 'report': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('feedback', '<your message>') }, { quoted: msg })
                const ownerJid = config.ownerNumber.replace(/\D/g,'') + '@s.whatsapp.net'
                await sock.sendMessage(ownerJid, {
                    text: fmt.box('FEEDBACK', [
                        `📩 From: @${sender.split('@')[0]}`,
                        `📱 JID: ${sender}`,
                        ``,
                        `💬 *Message:*`,
                        q,
                    ])
                })
                await sock.sendMessage(from, { text: `✅ Feedback sent to owner! Thank you.` }, { quoted: msg })
                break
            }

            // ════ DEBUG OWNER ═════════════════════════════════════════════════
            case 'debugowner': {
                const { jidToNum, normNum } = require('./lib/utils')
                const sNum   = jidToNum(sender)
                const oNum   = normNum(config.ownerNumber)
                const bNum   = jidToNum(botJid)
                await sock.sendMessage(from, {
                    text: fmt.box('🔍 OWNER DEBUG', [
                        `*Your JID:*    ${sender}`,
                        `*Your number:* ${sNum}`,
                        fmt.divider(),
                        `*Bot JID:*     ${botJid}`,
                        `*Bot number:*  ${bNum}`,
                        fmt.divider(),
                        `*Config owner:*  ${config.ownerNumber}`,
                        `*Config number:* ${oNum}`,
                        fmt.divider(),
                        `*isOwner:*    ${owner ? '✅ YES' : '❌ NO'}`,
                        `*fromMe:*     ${msg.key?.fromMe ? 'true' : 'false'}`,
                        `*inGroup:*    ${inGroup ? 'true' : 'false'}`,
                        ``,
                        owner
                            ? `✅ _You are recognized as owner_`
                            : `❌ _Not recognized — set OWNER_NUMBER=${sNum} in env_`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ STICKER ═════════════════════════════════════════════════════
            case 'sticker': case 's':
                await makeSticker(sock, msg, from, q)
                break

            // ════ TO IMAGE ════════════════════════════════════════════════════
            case 'toimage': case 'toimg': {
                const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
                if (!quoted?.stickerMessage) {
                    return sock.sendMessage(from, { text: fmt.box('TO IMAGE', [`❌ Reply to a *sticker* with *${prefix}toimage*`]) }, { quoted: msg })
                }
                try {
                    await fmt.react(sock, msg, '⏳')
                    const { downloadMediaMessage } = require('@whiskeysockets/baileys')
                    const silentLog = { level: 'silent', child: () => silentLog, info: () => {}, debug: () => {}, error: () => {}, warn: () => {}, trace: () => {} }
                    const buf = await downloadMediaMessage(
                        { message: quoted, key: msg.key }, 'buffer', {},
                        { logger: silentLog, reuploadRequest: sock.updateMediaMessage }
                    )
                    await sock.sendMessage(from, { image: buf, caption: `🖼️ Sticker converted to image` }, { quoted: msg })
                    await fmt.react(sock, msg, '✅')
                } catch (e) {
                    await sock.sendMessage(from, { text: fmt.box('ERROR', [`❌ ${e.message}`]) }, { quoted: msg })
                }
                break
            }

            // ════ VIEW ONCE REVEAL ════════════════════════════════════════════
            case 'vv': case 'reveal': case 'antiviewonce': {
                const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
                const vMsg   = quoted?.viewOnceMessage?.message || quoted?.viewOnceMessageV2?.message
                if (!vMsg) return sock.sendMessage(from, { text: fmt.box('REVEAL', [`❌ Reply to a *view-once* message with *${prefix}vv*`]) }, { quoted: msg })
                try {
                    await fmt.react(sock, msg, '⏳')
                    const { downloadMediaMessage } = require('@whiskeysockets/baileys')
                    const silentLog = { level: 'silent', child: () => silentLog, info: () => {}, debug: () => {}, error: () => {}, warn: () => {}, trace: () => {} }
                    const buf = await downloadMediaMessage(
                        { message: vMsg, key: msg.key }, 'buffer', {},
                        { logger: silentLog, reuploadRequest: sock.updateMediaMessage }
                    )
                    const mtype = Object.keys(vMsg)[0]
                    if (mtype === 'imageMessage') {
                        await sock.sendMessage(from, { image: buf, caption: `👁️ View-once revealed` }, { quoted: msg })
                    } else if (mtype === 'videoMessage') {
                        await sock.sendMessage(from, { video: buf, caption: `👁️ View-once revealed` }, { quoted: msg })
                    }
                    await fmt.react(sock, msg, '✅')
                } catch (e) {
                    await sock.sendMessage(from, { text: fmt.box('ERROR', [`❌ ${e.message}`]) }, { quoted: msg })
                }
                break
            }

            // ════ GET PROFILE PICTURE ═════════════════════════════════════════
            case 'getpp': case 'pfp': {
                const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
                const target    = mentioned[0] || sender
                try {
                    await fmt.react(sock, msg, '⏳')
                    const ppUrl = await sock.profilePictureUrl(target, 'image')
                    await sock.sendMessage(from, { image: { url: ppUrl }, caption: `🖼️ Profile picture of @${target.split('@')[0]}`, mentions: [target] }, { quoted: msg })
                    await fmt.react(sock, msg, '✅')
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('NO PP', [`❌ No profile picture found for @${target.split('@')[0]}`]), mentions: [target] }, { quoted: msg })
                }
                break
            }

            // ════ GET ABOUT ═══════════════════════════════════════════════════
            case 'getabout': case 'about': {
                const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
                const target    = mentioned[0] || sender
                try {
                    const info = await sock.fetchStatus(target)
                    await sock.sendMessage(from, {
                        text: fmt.box('ABOUT', [
                            `👤 @${target.split('@')[0]}`,
                            ``,
                            `📝 _${info?.status || 'No status set'}_`,
                        ]),
                        mentions: [target]
                    }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('ABOUT', [`❌ Could not fetch status`]) }, { quoted: msg })
                }
                break
            }

            // ════ DEVICE ══════════════════════════════════════════════════════
            case 'device': {
                const os = require('os')
                await sock.sendMessage(from, {
                    text: fmt.box('HOST INFO', [
                        `🖥️ *Platform:* ${os.platform()} (${os.arch()})`,
                        `💾 *RAM:* ${Math.round((os.totalmem() - os.freemem()) / 1024 / 1024)}MB / ${(os.totalmem() / 1024 / 1024 / 1024).toFixed(1)}GB`,
                        `⚙️ *CPUs:* ${os.cpus().length}x ${os.cpus()[0]?.model?.trim().substring(0, 30)}`,
                        `⏱ *Uptime:* ${Math.floor(os.uptime() / 3600)}h ${Math.floor((os.uptime() % 3600) / 60)}m`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ WEATHER ═════════════════════════════════════════════════════
            case 'weather': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('weather', '<city>') }, { quoted: msg })
                try {
                    await fmt.react(sock, msg, '⏳')
                    const res  = await fetch(`https://wttr.in/${encodeURIComponent(q)}?format=j1`, { signal: AbortSignal.timeout(10000) })
                    const data = await res.json()
                    const cur  = data.current_condition?.[0]
                    const area = data.nearest_area?.[0]
                    if (!cur) throw new Error('No data')
                    const city = area?.areaName?.[0]?.value + ', ' + area?.country?.[0]?.value
                    await sock.sendMessage(from, {
                        text: fmt.box('WEATHER', [
                            `🌍 *${city}*`,
                            `🌡️ *Temp:* ${cur.temp_C}°C / ${cur.temp_F}°F  (Feels ${cur.FeelsLikeC}°C)`,
                            `☁️ *Condition:* ${cur.weatherDesc?.[0]?.value}`,
                            `💧 *Humidity:* ${cur.humidity}%`,
                            `💨 *Wind:* ${cur.windspeedKmph} km/h ${cur.winddir16Point}`,
                            `👁️ *Visibility:* ${cur.visibility} km`,
                        ])
                    }, { quoted: msg })
                } catch (e) {
                    await sock.sendMessage(from, { text: fmt.box('WEATHER', [`❌ Could not fetch weather for *${q}*`]) }, { quoted: msg })
                }
                break
            }

            // ════ DEFINE (DICTIONARY) ═════════════════════════════════════════
            case 'define': case 'dict': case 'meaning': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('define', '<word>') }, { quoted: msg })
                try {
                    await fmt.react(sock, msg, '⏳')
                    const res  = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(q)}`, { signal: AbortSignal.timeout(10000) })
                    const data = await res.json()
                    if (!Array.isArray(data)) throw new Error('Not found')
                    const entry   = data[0]
                    const meaning = entry.meanings?.[0]
                    const def     = meaning?.definitions?.[0]
                    await sock.sendMessage(from, {
                        text: fmt.box('DICTIONARY', [
                            `📖 *${entry.word}*`,
                            entry.phonetic ? `🔤 *Phonetic:* ${entry.phonetic}` : null,
                            ``,
                            `📝 *${meaning?.partOfSpeech}:*`,
                            def?.definition,
                            def?.example ? `\n💡 _Example: "${def.example}"_` : null,
                            meaning?.synonyms?.length ? `\n🔁 *Synonyms:* ${meaning.synonyms.slice(0, 5).join(', ')}` : null,
                        ].filter(Boolean))
                    }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('NOT FOUND', [`❌ No definition found for: *${q}*`]) }, { quoted: msg })
                }
                break
            }

            // ════ TRANSLATE ═══════════════════════════════════════════════════
            case 'translate': case 'tr': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('translate', '<lang> <text>\nExample: .translate fr Hello world') }, { quoted: msg })
                const [lang, ...rest] = args
                const text = rest.join(' ')
                if (!text) return sock.sendMessage(from, { text: fmt.usage('translate', '<lang> <text>') }, { quoted: msg })
                try {
                    await fmt.react(sock, msg, '⏳')
                    const res  = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${encodeURIComponent(lang)}`, { signal: AbortSignal.timeout(12000) })
                    const data = await res.json()
                    const translated = data.responseData?.translatedText
                    if (!translated || translated.toLowerCase() === text.toLowerCase()) throw new Error('Translation failed')
                    await sock.sendMessage(from, {
                        text: fmt.box('TRANSLATE', [
                            `🔤 *Original:* ${text}`,
                            `🌐 *Language:* ${lang.toUpperCase()}`,
                            `✅ *Translated:* ${translated}`,
                        ])
                    }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('TRANSLATE', [`❌ Translation failed. Try language codes like: en, fr, es, ar, sw, de, zh`]) }, { quoted: msg })
                }
                break
            }

            // ════ CALCULATE ═══════════════════════════════════════════════════
            case 'calc': case 'calculate': case 'math': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('calc', '<expression>\nExample: .calc 2+2*10') }, { quoted: msg })
                try {
                    const safe = q.replace(/[^0-9+\-*/().%\s^]/g, '')
                    if (!safe) throw new Error('Invalid expression')
                    // eslint-disable-next-line no-eval
                    const result = Function('"use strict"; return (' + safe + ')')()
                    await sock.sendMessage(from, {
                        text: fmt.box('CALCULATOR', [`🧮 *${q}* = *${result}*`])
                    }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('ERROR', [`❌ Invalid expression: *${q}*`]) }, { quoted: msg })
                }
                break
            }

            // ════ QR CODE ═════════════════════════════════════════════════════
            case 'qr': case 'qrcode': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('qr', '<text or URL>') }, { quoted: msg })
                try {
                    await fmt.react(sock, msg, '⏳')
                    const url = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(q)}&format=png`
                    await sock.sendMessage(from, { image: { url }, caption: `📷 QR Code for:\n_${q}_` }, { quoted: msg })
                    await fmt.react(sock, msg, '✅')
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('ERROR', ['❌ Could not generate QR code']) }, { quoted: msg })
                }
                break
            }

            // ════ TINY URL ════════════════════════════════════════════════════
            case 'tinyurl': case 'shorten': case 'shorturl': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('tinyurl', '<URL>') }, { quoted: msg })
                try {
                    await fmt.react(sock, msg, '⏳')
                    const res  = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(q)}`, { signal: AbortSignal.timeout(10000) })
                    const short = await res.text()
                    if (!short.startsWith('http')) throw new Error('Failed')
                    await sock.sendMessage(from, {
                        text: fmt.box('URL SHORTENER', [`🔗 *Original:* ${q}`, `✅ *Short:* ${short}`])
                    }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('ERROR', ['❌ Could not shorten URL']) }, { quoted: msg })
                }
                break
            }

            // ════ GENERATE PASSWORD ═══════════════════════════════════════════
            case 'genpass': case 'password': {
                const len = Math.min(Math.max(parseInt(q) || 16, 8), 64)
                const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%^&*'
                let pass = ''
                for (let i = 0; i < len; i++) pass += chars[Math.floor(Math.random() * chars.length)]
                await sock.sendMessage(from, {
                    text: fmt.box('PASSWORD GENERATOR', [
                        `🔐 *Generated Password (${len} chars):*`,
                        `\`${pass}\``,
                        ``,
                        `⚠️ _Copy and save it — it won't be shown again_`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ FANCY TEXT ══════════════════════════════════════════════════
            case 'fancy': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('fancy', '<text>') }, { quoted: msg })
                const normal = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
                const bold   = '𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵'
                const italic = '𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡0123456789'
                const toBold = t => t.split('').map(c => { const i = normal.indexOf(c); return i >= 0 ? bold[i] : c }).join('')
                const toItalic = t => t.split('').map(c => { const i = normal.indexOf(c); return i >= 0 ? italic[i] : c }).join('')
                await sock.sendMessage(from, {
                    text: fmt.box('FANCY TEXT', [
                        `🅱️ *Bold:* ${toBold(q)}`,
                        `📝 *Italic:* ${toItalic(q)}`,
                        `✨ *Spaces:* ${q.split('').join(' ')}`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ FLIP TEXT ═══════════════════════════════════════════════════
            case 'fliptext': case 'reverse': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('fliptext', '<text>') }, { quoted: msg })
                const reversed = q.split('').reverse().join('')
                await sock.sendMessage(from, {
                    text: fmt.box('FLIP TEXT', [`🔄 *Original:* ${q}`, `↩️ *Reversed:* ${reversed}`])
                }, { quoted: msg })
                break
            }

            // ════ SAY (TTS alternative) ═══════════════════════════════════════
            case 'say': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('say', '<text>') }, { quoted: msg })
                await sock.sendMessage(from, { text: `🗣️ _${q}_` }, { quoted: msg })
                break
            }

            // ════ AI COMMANDS ═════════════════════════════════════════════════
            case 'ai': case 'gpt': case 'ask': case 'bot': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage(cmd, '<your question or request>') }, { quoted: msg })
                await aiReply(sock, from, q, msg)
                break
            }

            case 'gemini': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('gemini', '<question>') }, { quoted: msg })
                const tmpKey = config.geminiApiKey
                if (!tmpKey) config.geminiApiKey = undefined
                await aiReply(sock, from, q, msg)
                break
            }

            case 'deepseek': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('deepseek', '<question>') }, { quoted: msg })
                await aiReply(sock, from, `[DeepSeek] ${q}`, msg)
                break
            }

            case 'analyze': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('analyze', '<topic to analyze>') }, { quoted: msg })
                await aiReply(sock, from, `Give a detailed analysis of: ${q}`, msg)
                break
            }

            case 'code': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('code', '<describe what to code>') }, { quoted: msg })
                await aiReply(sock, from, `Write code for: ${q}`, msg)
                break
            }

            case 'story': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('story', '<story topic>') }, { quoted: msg })
                await aiReply(sock, from, `Write a short creative story about: ${q}`, msg)
                break
            }

            case 'recipe': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('recipe', '<dish name>') }, { quoted: msg })
                await aiReply(sock, from, `Give me a detailed recipe for: ${q}`, msg)
                break
            }

            case 'summarize': case 'summary': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('summarize', '<text to summarize>') }, { quoted: msg })
                await aiReply(sock, from, `Summarize this in bullet points: ${q}`, msg)
                break
            }

            case 'teach': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('teach', '<topic to learn>') }, { quoted: msg })
                await aiReply(sock, from, `Explain clearly and simply: ${q}`, msg)
                break
            }

            case 'generate': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('generate', '<idea>') }, { quoted: msg })
                await aiReply(sock, from, `Generate creative ideas for: ${q}`, msg)
                break
            }

            // ════ SEARCH ══════════════════════════════════════════════════════
            case 'lyrics': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('lyrics', '<artist - song title>') }, { quoted: msg })
                await fmt.react(sock, msg, '⏳')
                const result = await getLyrics(q)
                await sock.sendMessage(from, { text: result }, { quoted: msg })
                break
            }

            case 'imdb': case 'movie': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('imdb', '<movie title>') }, { quoted: msg })
                await fmt.react(sock, msg, '⏳')
                const result = await getIMDB(q)
                await sock.sendMessage(from, { text: result }, { quoted: msg })
                break
            }

            case 'yts': case 'torrent': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('yts', '<movie title>') }, { quoted: msg })
                await fmt.react(sock, msg, '⏳')
                const result = await getYTS(q)
                await sock.sendMessage(from, { text: result }, { quoted: msg })
                break
            }

            case 'wallpaper': case 'wp': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('wallpaper', '<keyword>') }, { quoted: msg })
                await fmt.react(sock, msg, '⏳')
                await getWallpaper(sock, from, q, msg)
                break
            }

            case 'gsmarena': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('gsmarena', '<phone model>') }, { quoted: msg })
                await fmt.react(sock, msg, '⏳')
                await aiReply(sock, from, `Give me the full specifications for the phone: ${q}. Format as a spec sheet with bullet points.`, msg)
                break
            }

            // ════ RELIGION ════════════════════════════════════════════════════
            case 'bible': {
                await fmt.react(sock, msg, '📖')
                const result = await getBible(q || 'John 3:16')
                await sock.sendMessage(from, { text: result }, { quoted: msg })
                break
            }

            case 'quran': {
                await fmt.react(sock, msg, '🕌')
                const result = await getQuran(q || '255')
                await sock.sendMessage(from, { text: result }, { quoted: msg })
                break
            }

            // ════ FUN ═════════════════════════════════════════════════════════
            case 'fact': case 'facts': {
                await fmt.react(sock, msg, '🌍')
                await sock.sendMessage(from, { text: fmt.box('RANDOM FACT', [rand(facts)]) }, { quoted: msg })
                break
            }

            case 'joke': case 'jokes': {
                await fmt.react(sock, msg, '😂')
                await sock.sendMessage(from, { text: rand(jokes) }, { quoted: msg })
                break
            }

            case 'quote': case 'quotes': {
                await fmt.react(sock, msg, '💬')
                await sock.sendMessage(from, { text: rand(quotes) }, { quoted: msg })
                break
            }

            case 'trivia': {
                await fmt.react(sock, msg, '🧠')
                const t = rand(trivia)
                await sock.sendMessage(from, {
                    text: fmt.box('TRIVIA', [`❓ *${t.q}*`, ``, `_Reply to guess! Answer in 30s..._`])
                }, { quoted: msg })
                setTimeout(async () => {
                    try { await sock.sendMessage(from, { text: fmt.box('ANSWER', [`✅ *${t.a}*`]) }) } catch {}
                }, 30000)
                break
            }

            case 'truth': {
                await fmt.react(sock, msg, '🤔')
                await sock.sendMessage(from, { text: fmt.box('TRUTH', [rand(truthQs)]) }, { quoted: msg })
                break
            }

            case 'dare': {
                await fmt.react(sock, msg, '🎯')
                await sock.sendMessage(from, { text: fmt.box('DARE', [rand(dares)]) }, { quoted: msg })
                break
            }

            case 'truthordare': case 'tod': {
                await fmt.react(sock, msg, '🎲')
                const isTruth = Math.random() < 0.5
                if (isTruth) {
                    await sock.sendMessage(from, { text: fmt.box('TRUTH', [rand(truthQs)]) }, { quoted: msg })
                } else {
                    await sock.sendMessage(from, { text: fmt.box('DARE', [rand(dares)]) }, { quoted: msg })
                }
                break
            }

            case 'truthdetector': {
                if (!q) return sock.sendMessage(from, { text: fmt.usage('truthdetector', '<statement>') }, { quoted: msg })
                const pct = Math.floor(Math.random() * 101)
                const bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10))
                await sock.sendMessage(from, {
                    text: fmt.box('TRUTH DETECTOR 🔍', [
                        `📝 Statement: _${q}_`,
                        ``,
                        `[${bar}] ${pct}%`,
                        ``,
                        pct > 70 ? `✅ *Likely TRUE*` : pct > 40 ? `🟡 *Uncertain*` : `❌ *Likely FALSE*`,
                        ``,
                        `_This is for entertainment only 😄_`,
                    ])
                }, { quoted: msg })
                break
            }

            case 'memes': case 'meme': {
                try {
                    await fmt.react(sock, msg, '😂')
                    const cats  = ['programming', 'dank', 'funny', 'dark', 'wholesome']
                    const cat   = cats[Math.floor(Math.random() * cats.length)]
                    const res   = await fetch(`https://meme-api.com/gimme/${cat}`, { signal: AbortSignal.timeout(10000) })
                    const data  = await res.json()
                    if (!data?.url) throw new Error('No meme')
                    await sock.sendMessage(from, { image: { url: data.url }, caption: `😂 *${data.title}*\n👍 ${data.ups} upvotes` }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { text: fmt.box('MEME', [`❌ Could not fetch meme. Try again!`]) }, { quoted: msg })
                }
                break
            }

            case 'emojimix': {
                if (args.length < 2) return sock.sendMessage(from, { text: fmt.usage('emojimix', '<emoji1> <emoji2>\nExample: .emojimix 😀 😂') }, { quoted: msg })
                const e1 = encodeURIComponent(args[0]), e2 = encodeURIComponent(args[1])
                const url = `https://emojicdn.elk.sh/${args[0]}?style=google`
                await sock.sendMessage(from, {
                    text: fmt.box('EMOJI MIX', [
                        `✨ Mixing: ${args[0]} + ${args[1]}`,
                        ``,
                        `🎨 *Result:* ${args[0]}${args[1]}`,
                        ``,
                        `_Google Emoji Mixer: emojikitchen.dev_`,
                    ])
                }, { quoted: msg })
                break
            }

            // ════ IMAGE ═══════════════════════════════════════════════════════
            case 'remini': case 'enhance': {
                await fmt.react(sock, msg, '⏳')
                await getRemini(sock, from, msg)
                break
            }

            // ════ OWNER COMMANDS (owner guard is above) ════════════════════════
            default: {
                // Custom command management (addcmd, delcmd, editcmd, listcmd, cmdinfo)
                const customBuilderCmds = new Set(['addcmd','delcmd','editcmd','listcmd','listcmds','mycmds','cmdinfo'])
                if (customBuilderCmds.has(cmd)) {
                    await handleCustomCmdBuilder(sock, from, cmd, q, msg, prefix)
                    break
                }

                // All other owner-only commands
                if (ownerOnlyCmds.has(cmd)) {
                    await handleOwnerCmd(sock, from, cmd, args, q, msg, sender)
                    break
                }

                // Truly unknown command
                await sock.sendMessage(from, {
                    text: fmt.box('UNKNOWN COMMAND', [
                        `❓ *${prefix}${cmd}* is not a valid command`,
                        ``,
                        `📋 Use *${prefix}menu* to see all available commands`,
                    ])
                }, { quoted: msg })
                break
            }
        }
    } catch (e) {
        console.error('Handler error:', e.message, e.stack?.split('\n')[1])
    }
}

module.exports = { handleMessage }
