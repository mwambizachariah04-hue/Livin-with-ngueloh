'use strict'
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys')
const { Boom }  = require('@hapi/boom')
const pino      = require('pino')
const config    = require('./config')
const fmt       = require('./lib/format')
const { getBody, getSender, isOwner } = require('./lib/utils')
const { runtimeSettings, STATUS_EMOJIS } = require('./plugins/ownerCmds')
const { handleMessage }    = require('./handler')
const { handleGroupEvents } = require('./plugins/groups')

const log     = pino({ level: 'silent' })
const seen    = new Set()
const rateMap = new Map()
let onlineSent = false, retries = 0, retryTimer = null

function dedup(id) {
    if (!id || seen.has(id)) return false
    seen.add(id)
    if (seen.size > 2000) {
        const a = [...seen]; seen.clear(); a.slice(-1000).forEach(i => seen.add(i))
    }
    return true
}

function rateOk(jid) {
    const now = Date.now(), last = rateMap.get(jid) || 0
    if (now - last < 2000) return false
    rateMap.set(jid, now)
    return true
}

function showCode(code, phone) {
    // Format as XXXX-XXXX
    const show = (code || '').replace(/\W/g, '').match(/.{1,4}/g)?.join('-') || code
    console.log('\n' + '━'.repeat(52))
    console.log('  🔑  PAIRING CODE  →  ' + show)
    console.log('━'.repeat(52))
    console.log('\n  Steps to link on WhatsApp:')
    console.log('  1. Open WhatsApp → tap ⋮ (3-dot menu)')
    console.log('  2. Linked Devices → Link a Device')
    console.log('  3. Tap "Link with phone number"')
    console.log('  4. Enter your number: ' + phone)
    console.log('  5. Enter the code above')
    console.log('\n  ⚠  Code expires in ~60 seconds.')
    console.log('     If it says invalid → delete the auth_info')
    console.log('     folder and restart the bot for a fresh code.\n')
}

async function connect() {
    if (retryTimer) { clearTimeout(retryTimer); retryTimer = null }

    const { state, saveCreds } = await useMultiFileAuthState('./auth_info')

    let version = [2, 3000, 1015920675]
    try {
        const r = await Promise.race([
            fetchLatestBaileysVersion(),
            new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000)),
        ])
        version = r.version
        console.log('Baileys version:', version.join('.'))
    } catch {
        console.log('Using fallback Baileys version:', version.join('.'))
    }

    // Sanitise phone number — digits only, with country code, no +
    const phone = (config.ownerNumber || '').replace(/\D/g, '')
    const needsPairing = !state.creds.registered

    console.log('\n' + '═'.repeat(52))
    console.log('  Bot   : ' + config.botName)
    console.log('  Owner : ' + config.ownerName)
    console.log('  Number: ' + phone)
    console.log('  Prefix: ' + config.prefix)
    console.log('  Paired: ' + (needsPairing ? 'NO' : 'YES ✅'))
    console.log('═'.repeat(52) + '\n')

    if (needsPairing) {
        if (!phone || phone.length < 7) {
            console.error('❌  ownerNumber in config.js is missing or invalid. Set it then restart.\n')
            process.exit(1)
        }
        console.log('⏳  Waiting for WhatsApp handshake before requesting code...')
        console.log('    (This usually takes 5-10 seconds)\n')
    }

    // ── Socket ────────────────────────────────────────────────────────────────
    // IMPORTANT for pairing code validity:
    //   • browser MUST use Baileys' built-in Browsers helper, not a custom string.
    //   • mobile MUST be false (tells Baileys to use the multi-device Web protocol).
    // ─────────────────────────────────────────────────────────────────────────
    const sock = makeWASocket({
        version,
        logger: log,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, log),
        },
        browser: Browsers.ubuntu('Chrome'),  // ← must be standard, not custom
        mobile: false,                        // ← must be false for pairing code
        printQRInTerminal: false,             // ← no QR; we use pairing code
        syncFullHistory: false,
        connectTimeoutMs: 60_000,
        keepAliveIntervalMs: 30_000,
        retryRequestDelayMs: 3_000,
        markOnlineOnConnect: false,
        getMessage: async () => undefined,
    })

    sock.ev.on('creds.update', saveCreds)

    let pairingRequested = false

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update

        // ── Pairing code ──────────────────────────────────────────────────────
        // The 'qr' field in connection.update signals that WhatsApp has
        // completed the WebSocket/Noise handshake and is waiting for auth.
        // This is the ONLY correct moment to call requestPairingCode().
        // ─────────────────────────────────────────────────────────────────────
        if (qr && needsPairing && !pairingRequested) {
            pairingRequested = true
            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    console.log(`  Requesting pairing code (attempt ${attempt}/3)...`)
                    const code = await sock.requestPairingCode(phone)
                    showCode(code, phone)
                    break
                } catch (e) {
                    console.log(`  Attempt ${attempt} failed: ${e.message}`)
                    if (attempt < 3) {
                        await new Promise(r => setTimeout(r, 5000))
                    } else {
                        console.log('\n💡 Could not get code. Delete auth_info folder and restart.\n')
                    }
                }
            }
        }

        if (connection === 'connecting') {
            console.log('Connecting to WhatsApp servers...')
        }

        if (connection === 'open') {
            retries = 0
            pairingRequested = false
            console.log('✅ Bot connected!\n')

            if (runtimeSettings.alwaysonline) {
                try { await sock.sendPresenceUpdate('available') } catch {}
            }

            if (!onlineSent) {
                onlineSent = true
                setTimeout(async () => {
                    try {
                        await sock.sendMessage(phone + '@s.whatsapp.net', {
                            text: fmt.box(config.botName + ' — ONLINE', [
                                '✅ Bot is *online* and ready!', '',
                                '👤 Owner: *' + config.ownerName + '*',
                                '⚡ Prefix: *' + config.prefix + '*',
                                '🌐 Mode: *' + (config.mode || 'public').toUpperCase() + '*', '',
                                'Type *' + config.prefix + 'menu* to get started',
                            ])
                        })
                    } catch {}
                }, 4000)
            }
        }

        if (connection === 'close') {
            const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode
            console.log('Disconnected. Status code:', statusCode)

            if (statusCode === DisconnectReason.loggedOut || statusCode === 401 || statusCode === 403) {
                console.log('Session logged out. Delete the auth_info folder and restart.')
                process.exit(1)
            }

            if (statusCode === DisconnectReason.restartRequired) {
                connect()
                return
            }

            retries = Math.min(retries + 1, 10)
            const delay = retries * 5
            console.log(`Reconnecting in ${delay}s...`)
            retryTimer = setTimeout(connect, delay * 1000)
        }
    })

    // ── Messages ──────────────────────────────────────────────────────────────
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        for (const msg of messages) {
            try {
                if (!msg?.message) continue
                if (!dedup(msg.key.id)) continue

                const jid = msg.key.remoteJid || ''

                if (jid === 'status@broadcast') {
                    const poster = msg.key.participant || ''
                    if (runtimeSettings.autoviewstatus && poster) {
                        try { await sock.sendReceipt('status@broadcast', poster, [msg.key.id], 'read') } catch {}
                    }
                    if (runtimeSettings.autoreactstatus && poster) {
                        try {
                            const e = STATUS_EMOJIS[Math.floor(Math.random() * STATUS_EMOJIS.length)]
                            await sock.sendMessage(poster, {
                                react: {
                                    text: e,
                                    key: { remoteJid: 'status@broadcast', id: msg.key.id, participant: poster, fromMe: false }
                                }
                            })
                        } catch {}
                    }
                    continue
                }

                // Allow 'notify' (new) and 'append' (received while offline/reconnecting)
                // Reject only 'replace' (edits) and anything else that's not a real message
                if (type !== 'notify' && type !== 'append') continue
                const ks = Object.keys(msg.message || {})
                if (ks.length === 1 && ks[0] === 'reactionMessage') continue

                if (msg.key.fromMe) {
                    const b = getBody(msg)
                    if (!b || !b.startsWith(config.prefix)) continue
                }

                const botJid = sock.user?.id || ''
                const sender = getSender(msg, botJid)
                if (!isOwner(sender, botJid, msg.key?.fromMe) && !rateOk(sender)) {
                    // Tell the user they're going too fast instead of silently dropping
                    try {
                        await sock.sendMessage(jid, {
                            text: `⏱ Slow down! Wait a moment before sending another command.`
                        }, { quoted: msg })
                    } catch {}
                    continue
                }

                if (runtimeSettings.autoread) {
                    try { await sock.readMessages([msg.key]) } catch {}
                }
                if (runtimeSettings.autoreact && !msg.key.fromMe && Math.random() < 0.25) {
                    try {
                        const e = STATUS_EMOJIS[Math.floor(Math.random() * STATUS_EMOJIS.length)]
                        await sock.sendMessage(jid, { react: { text: e, key: msg.key } })
                    } catch {}
                }

                await handleMessage(sock, msg)
            } catch (e) {
                console.error('Message error:', e.message)
            }
        }
    })

    // ── Group events ──────────────────────────────────────────────────────────
    sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
        try { await handleGroupEvents(sock, id, participants, action) } catch {}
    })

    // ── Calls ─────────────────────────────────────────────────────────────────
    sock.ev.on('call', async calls => {
        for (const call of calls) {
            if (runtimeSettings.anticall && call.status === 'offer') {
                try { await sock.rejectCall(call.id, call.from) } catch {}
            }
        }
    })
}

connect().catch(e => { console.error('Fatal error:', e.message); process.exit(1) })
process.on('unhandledRejection', e => console.error('Unhandled rejection:', e?.message || e))
process.on('uncaughtException',  e => console.error('Uncaught exception:',  e?.message || e))
