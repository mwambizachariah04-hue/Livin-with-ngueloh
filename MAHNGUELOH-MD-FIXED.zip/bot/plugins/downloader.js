'use strict'
/**
 * ╔══════════════════════════════════════════════════════╗
 * ║   MAHNGUELOH-MD  —  Downloader  v3.0                ║
 * ║   Production-grade media downloader                  ║
 * ╠══════════════════════════════════════════════════════╣
 * ║  Music  : JioSaavn → Cobalt(YT) → yt-dlp            ║
 * ║  YouTube: Cobalt   → yt-dlp                          ║
 * ║  TikTok : TikWM    → Cobalt → yt-dlp                ║
 * ║  IG/TW  : Cobalt   → yt-dlp                         ║
 * ║  FB     : Cobalt   → yt-dlp                         ║
 * ║  Spotify: oEmbed → JioSaavn/YT → Cobalt             ║
 * ║  MFire  : HTML parse → direct download               ║
 * ╚══════════════════════════════════════════════════════╝
 */

const config   = require('../config')
const fmt      = require('../lib/format')
const { exec } = require('child_process')
const fs       = require('fs')
const os       = require('os')
const path     = require('path')

// ══════════════════════════════════════════════════════════════════════════════
//  CONSTANTS
// ══════════════════════════════════════════════════════════════════════════════

const MAX_MUSIC_SECS  = 900   // 15 min  — anything longer is not a song
const MAX_VIDEO_SECS  = 1200  // 20 min  — for video downloads
const MAX_BYTES       = (config.maxDownloadSize || 80) * 1024 * 1024
const MIN_BYTES       = 2000  // reject files smaller than 2 KB
const UA              = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36'

const COBALT_HOSTS = [
    'https://api.cobalt.tools',
    'https://cobalt.api.timelessnesses.me',
    'https://cobalt.ayo.tf',
    'https://cobalt.catvibers.me',
]

// ══════════════════════════════════════════════════════════════════════════════
//  UTILITIES
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Retry wrapper — retries `fn` up to `attempts` times with growing delay.
 * Returns result on first success, throws last error if all fail.
 */
async function withRetry(fn, attempts = 3, baseDelayMs = 1500) {
    let lastErr
    for (let i = 0; i < attempts; i++) {
        try { return await fn() }
        catch (e) {
            lastErr = e
            if (i < attempts - 1) await sleep(baseDelayMs * (i + 1))
        }
    }
    throw lastErr
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

function makeId() { return `dl_${Date.now()}_${Math.random().toString(36).slice(2, 7)}` }

function fmtDur(secs) {
    if (!secs) return '?:??'
    const s = Math.round(Number(secs))
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    const sec = s % 60
    return h > 0
        ? `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
        : `${m}:${String(sec).padStart(2,'0')}`
}

function fmtSize(bytes) {
    if (!bytes) return ''
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

/**
 * Fetch URL → Buffer with full validation.
 * Throws descriptive errors so the caller can try the next provider.
 */
async function toBuffer(url, opts = {}) {
    const { headers = {}, timeoutMs = 90_000, label = '' } = opts
    if (!url || typeof url !== 'string') throw new Error('Invalid URL')

    const res = await fetch(url, {
        headers: { 'User-Agent': UA, ...headers },
        signal:  AbortSignal.timeout(timeoutMs),
        redirect: 'follow',
    })
    if (!res.ok) throw new Error(`${label || new URL(url).hostname} returned HTTP ${res.status}`)

    const buf = Buffer.from(await res.arrayBuffer())
    if (buf.length < MIN_BYTES)  throw new Error(`File too small (${buf.length} bytes) — likely an error page`)
    if (buf.length > MAX_BYTES)  throw new Error(`File too large: ${fmtSize(buf.length)} (limit ${fmtSize(MAX_BYTES)})`)
    return buf
}

/**
 * Validate a media buffer — checks it's a real audio or video file by magic bytes.
 */
function validateMedia(buf, type = 'audio') {
    if (!buf || buf.length < MIN_BYTES) return false
    // MP3: ID3 tag or MPEG sync
    if (type === 'audio') {
        return buf[0] === 0x49 && buf[1] === 0x44 && buf[2] === 0x33  // ID3
            || buf[0] === 0xFF && (buf[1] & 0xE0) === 0xE0              // MPEG sync
            || buf[0] === 0x66 && buf[1] === 0x74 && buf[2] === 0x79    // ftyp (m4a)
            || buf[0] === 0x4F && buf[1] === 0x67 && buf[2] === 0x67    // OGG
            || true // accept if large enough (covers webm wrapped MP3)
    }
    // MP4: ftyp box
    if (type === 'video') {
        const magic = buf.slice(4, 8).toString('ascii')
        return magic === 'ftyp' || magic === 'mdat' || magic === 'moov'
            || buf[0] === 0x1A && buf[1] === 0x45  // WebM/MKV
            || buf.length > 100_000  // accept large buffer as likely valid video
    }
    return true
}

/**
 * Clean up any temp files matching a prefix.
 */
function cleanTmp(prefix) {
    try {
        fs.readdirSync(os.tmpdir())
            .filter(f => f.startsWith(prefix))
            .forEach(f => { try { fs.unlinkSync(path.join(os.tmpdir(), f)) } catch {} })
    } catch {}
}

// ══════════════════════════════════════════════════════════════════════════════
//  YT-DLP  (server-side binary — best quality, no rate limits)
// ══════════════════════════════════════════════════════════════════════════════

let _ytdlpOk = null  // cache availability check

async function hasYtdlp() {
    if (_ytdlpOk !== null) return _ytdlpOk
    _ytdlpOk = await new Promise(r => exec('yt-dlp --version', e => r(!e)))
    return _ytdlpOk
}

async function ytdlpDownload(url, audioOnly) {
    const id  = makeId()
    const tmp = path.join(os.tmpdir(), id)

    const fmtArg = audioOnly
        ? `-x --audio-format mp3 --audio-quality 0`
        : `-f "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best[height<=720]" --merge-output-format mp4`

    await new Promise((resolve, reject) => {
        exec(
            `yt-dlp ${fmtArg} --no-playlist --retries 3 -o "${tmp}.%(ext)s" --no-warnings "${url}"`,
            { maxBuffer: 200 * 1024 * 1024, timeout: 150_000 },
            (err, _, stderr) => err ? reject(new Error((stderr || err.message).split('\n')[0])) : resolve()
        )
    })

    const ext   = audioOnly ? 'mp3' : 'mp4'
    const exact = `${tmp}.${ext}`
    const found = fs.existsSync(exact) ? exact
        : fs.readdirSync(os.tmpdir()).map(f => path.join(os.tmpdir(), f)).find(f => f.startsWith(tmp))

    if (!found) throw new Error('yt-dlp did not produce an output file')

    const buf = fs.readFileSync(found)
    cleanTmp(id)
    return buf
}

// ══════════════════════════════════════════════════════════════════════════════
//  COBALT.TOOLS  (multi-instance, both old + new API format)
// ══════════════════════════════════════════════════════════════════════════════

async function cobaltFetch(mediaUrl, audioOnly = false) {
    const body = JSON.stringify({
        url:           mediaUrl.trim(),
        downloadMode:  audioOnly ? 'audio' : 'auto',
        audioFormat:   'mp3',
        filenameStyle: 'basic',
    })

    const errors = []

    for (const host of COBALT_HOSTS) {
        try {
            const res = await fetch(host, {
                method:  'POST',
                headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                body,
                signal:  AbortSignal.timeout(22_000),
            })
            if (!res.ok) { errors.push(`${host} HTTP ${res.status}`); continue }

            const data = await res.json()
            if (data.status === 'error') { errors.push(`${host}: ${data.error?.code || 'API error'}`); continue }

            // New format: tunnel / redirect / stream
            const dlUrl = data.url || data.tunnel
            if (dlUrl) return dlUrl

            // Picker (Instagram/Twitter carousel)
            if (data.status === 'picker' && data.picker?.[0]?.url) return data.picker[0].url

        } catch (e) { errors.push(`${host}: ${e.message}`) }
    }

    throw new Error(`Cobalt unavailable — ${errors.slice(-2).join(' | ')}`)
}

// ══════════════════════════════════════════════════════════════════════════════
//  JIOSAAVN  (free music API — English + global catalog, real MP3 links)
// ══════════════════════════════════════════════════════════════════════════════

const SAAVN_HOSTS = [
    'https://saavn.dev',
    'https://jiosaavn.dev',
    'https://jiosaavn-api.vercel.app',
]

async function saavnSearch(query) {
    // Build multiple query variants to try — widens the search net
    const ql = query.toLowerCase().trim()
    const variants = [
        query,
        // strip common words that confuse JioSaavn
        ql.replace(/\b(official|audio|video|lyrics|hd|hq|ft\.?|feat\.?|remix)\b/gi, '').trim(),
        // try just the first 3 words
        ql.split(/\s+/).slice(0, 3).join(' '),
    ].filter((v, i, a) => v && a.indexOf(v) === i)  // unique, non-empty

    for (const q of variants) {
        for (const host of SAAVN_HOSTS) {
            try {
                const url = `${host}/api/search/songs?query=${encodeURIComponent(q)}&limit=10`
                const res  = await fetch(url, { signal: AbortSignal.timeout(12_000) })
                if (!res.ok) continue
                const data  = await res.json()
                const songs = data?.data?.results
                if (!songs?.length) continue

                // Smart scoring — prefer exact title matches and shorter durations
                const words = ql.split(/\s+/).filter(w => w.length > 2)
                const scored = songs
                    .filter(s => s.downloadUrl?.length)
                    .map(s => {
                        const title  = (s.name || '').toLowerCase()
                        const artist = (s.artists?.primary?.map(a => a.name).join(' ') || '').toLowerCase()
                        const full   = `${title} ${artist}`
                        let score = 0
                        if (title === ql)             score += 30   // perfect title match
                        if (full.includes(ql))        score += 15
                        if (title.includes(ql))       score += 10
                        if (artist.includes(ql))      score += 5
                        words.forEach(w => {
                            if (title.includes(w))  score += 3
                            if (artist.includes(w)) score += 1
                        })
                        // Slightly prefer shorter songs (more likely to be the right track)
                        const dur = Number(s.duration) || 999
                        if (dur < 300) score += 1
                        return { song: s, score }
                    })
                    .filter(x => x.score > 0)
                    .sort((a, b) => b.score - a.score)

                if (!scored.length) continue
                const { song } = scored[0]

                // Pick highest quality download URL
                const dlUrls = song.downloadUrl || []
                const best   = dlUrls.reduce((a, b) => parseInt(b.quality) > parseInt(a.quality) ? b : a, dlUrls[0])
                if (!best?.url) continue

                return {
                    title:    song.name || query,
                    author:   song.artists?.primary?.map(a => a.name).join(', ') || '',
                    album:    song.album?.name || '',
                    duration: fmtDur(song.duration),
                    secs:     Number(song.duration) || 0,
                    quality:  best.quality ? best.quality + 'kbps' : '',
                    dlUrl:    best.url,
                    image:    song.image?.[2]?.url || song.image?.[1]?.url || null,
                    source:   'JioSaavn',
                }
            } catch {}
        }
    }
    return null
}

// ══════════════════════════════════════════════════════════════════════════════
//  YOUTUBE SEARCH  (uses youtube-sr, already installed)
// ══════════════════════════════════════════════════════════════════════════════

async function ytSearch(query, opts = {}) {
    const { maxSecs = MAX_MUSIC_SECS, limit = 5 } = opts
    try {
        const YT      = require('youtube-sr').default
        const results = await YT.search(query, { limit, type: 'video', safeSearch: false })
        if (!results?.length) return null

        // Filter by duration + pick best match
        const valid = results.filter(v => {
            const secs = (v.duration || 0)
            return secs > 0 && secs <= maxSecs
        })

        const pool = valid.length ? valid : results.slice(0, 1)
        const v = pool[0]
        const d = v.duration || 0
        return {
            id:       v.id,
            title:    v.title || query,
            author:   v.channel?.name || '',
            duration: fmtDur(d),
            secs:     d,
            views:    v.views ? `${(v.views / 1_000_000).toFixed(1)}M views` : '',
            url:      `https://www.youtube.com/watch?v=${v.id}`,
            thumb:    v.thumbnail?.url || null,
        }
    } catch { return null }
}

// ══════════════════════════════════════════════════════════════════════════════
//  YOUTUBE AUDIO  (cobalt → free converters → ytdlp)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Get a direct audio download URL for a YouTube video ID.
 * Tries multiple methods in order — cobalt → innertube → free converters → yt-dlp.
 */
async function ytAudioUrl(videoId) {
    const ytUrl = `https://www.youtube.com/watch?v=${videoId}`

    // ── 1. Cobalt (best — native YT audio extraction) ────────────────────────
    try { return await cobaltFetch(ytUrl, true) } catch {}

    // ── 2. YouTube Innertube API (YouTube's own internal player API) ──────────
    //    Returns direct audio stream URLs — no third-party service needed.
    try {
        const body = JSON.stringify({
            context: {
                client: {
                    clientName: 'ANDROID',
                    clientVersion: '17.31.35',
                    androidSdkVersion: 30,
                    hl: 'en', gl: 'US',
                }
            },
            videoId,
        })
        const res = await fetch(
            'https://www.youtube.com/youtubei/v1/player?key=AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'com.google.android.youtube/17.31.35 (Linux; U; Android 11) gzip',
                    'X-Youtube-Client-Name': '3',
                    'X-Youtube-Client-Version': '17.31.35',
                },
                body,
                signal: AbortSignal.timeout(15_000),
            }
        )
        if (res.ok) {
            const data = await res.json()
            const adaptive = (data?.streamingData?.adaptiveFormats || [])
                .filter(f => f.mimeType?.startsWith('audio/') && f.url && !f.signatureCipher)
                .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))
            if (adaptive[0]?.url) return adaptive[0].url

            const regular = (data?.streamingData?.formats || [])
                .filter(f => f.url && !f.signatureCipher)
                .sort((a, b) => (a.bitrate || 0) - (b.bitrate || 0))
            if (regular[0]?.url) return regular[0].url
        }
    } catch {}

    // ── 3. Free converter APIs (rotated for redundancy) ───────────────────────
    const apis = [
        async () => {
            const r = await fetch(
                `https://p.oceansaver.in/ajax/download.php?format=mp3&url=${encodeURIComponent(ytUrl)}&api=`,
                { signal: AbortSignal.timeout(18_000) }
            )
            const d = await r.json()
            return (d?.success && d?.download_url) ? d.download_url : null
        },
        async () => {
            const r = await fetch(
                `https://api.fabdl.com/youtube/mp3?url=${encodeURIComponent(ytUrl)}`,
                { signal: AbortSignal.timeout(18_000) }
            )
            const d = await r.json()
            return d?.download_url || null
        },
        async () => {
            const r = await fetch(
                `https://yt5s.io/api/ajaxSearch/index`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body:   `q=${encodeURIComponent(ytUrl)}&vt=mp3`,
                    signal: AbortSignal.timeout(18_000),
                }
            )
            const d = await r.json()
            // yt5s returns conversion keys; grab the 128kbps link if available
            const key = Object.keys(d?.links?.mp3 || {})[0]
            return key ? d.links.mp3[key]?.url : null
        },
        async () => {
            // yt1s.io — post-conversion link
            const r = await fetch('https://yt1s.io/mates/en/convert', {
                method:  'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body:    `url=${encodeURIComponent(ytUrl)}&q=mp3&vt=mp4`,
                signal:  AbortSignal.timeout(18_000),
            })
            const d = await r.json()
            return d?.kv?.mp3 || null
        },
    ]

    for (const api of apis) {
        try { const u = await api(); if (u) return u } catch {}
    }

    return null
}

// ══════════════════════════════════════════════════════════════════════════════
//  TIKTOK  via TikWM (no-watermark, no API key needed)
// ══════════════════════════════════════════════════════════════════════════════

async function tikwmFetch(tiktokUrl, audioOnly = false) {
    const body = new URLSearchParams({
        url: tiktokUrl.trim(), count: '12', cursor: '0', web: '1', hd: '1'
    })

    const hosts = ['https://www.tikwm.com/api/', 'https://tikwm.com/api/']

    for (const host of hosts) {
        try {
            const res  = await fetch(host, {
                method:  'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': UA },
                body:    body.toString(),
                signal:  AbortSignal.timeout(20_000),
            })
            if (!res.ok) continue
            const data = await res.json()
            if (data.code !== 0 || !data.data) continue

            const d = data.data
            return {
                title:     d.title || 'TikTok Video',
                author:    d.author?.nickname || '',
                duration:  fmtDur(d.duration),
                secs:      d.duration || 0,
                size:      fmtSize(audioOnly ? d.music_info?.size : (d.size || d.hd_size)),
                videoUrl:  d.play || d.hdplay || d.wmplay,   // play = no watermark on TikWM
                audioUrl:  d.music,
                coverUrl:  d.cover || null,
                source:    'TikWM',
            }
        } catch {}
    }
    return null
}

// ══════════════════════════════════════════════════════════════════════════════
//  SPOTIFY  — oEmbed metadata → JioSaavn / YouTube match
// ══════════════════════════════════════════════════════════════════════════════

async function spotifyInfo(spotifyUrl) {
    try {
        // oEmbed gives us title + description without any API key
        const res = await fetch(
            `https://open.spotify.com/oembed?url=${encodeURIComponent(spotifyUrl)}`,
            { headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(12_000) }
        )
        if (!res.ok) throw new Error(`Spotify oEmbed HTTP ${res.status}`)
        const data = await res.json()

        // Title is usually "Song Name" and description contains "Artist · Album"
        const title = data.title || ''
        const desc  = (data.description || data.provider_url || '').replace(/·/g, '-')

        return { searchQuery: `${title} ${desc.split('-')[0]}`.trim(), title, image: data.thumbnail_url }
    } catch {
        // Fallback: parse the track ID and build a search query from the URL
        const match = spotifyUrl.match(/track\/([A-Za-z0-9]+)/)
        return match ? { searchQuery: `spotify track ${match[1]}` } : null
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  MEDIAFIRE  — parse HTML to extract direct download link
// ══════════════════════════════════════════════════════════════════════════════

async function mediaFireLink(mfUrl) {
    const res = await fetch(mfUrl, {
        headers: { 'User-Agent': UA },
        signal: AbortSignal.timeout(15_000),
        redirect: 'follow',
    })
    if (!res.ok) throw new Error(`MediaFire returned HTTP ${res.status}`)
    const html = await res.text()

    // Multiple extraction strategies
    const patterns = [
        /id="downloadButton"[^>]*href="([^"]+)"/i,
        /aria-label="Download file"[^>]*href="([^"]+)"/i,
        /<a[^>]+class="[^"]*btn[^"]*"[^>]*href="(https:\/\/download[^"]+)"/i,
        /href="(https:\/\/download\d*\.mediafire\.com\/[^"]+)"/i,
        /window\.location\.href\s*=\s*["'](https:\/\/[^"']+)["']/i,
    ]

    for (const re of patterns) {
        const m = html.match(re)
        if (m?.[1]) return decodeURIComponent(m[1])
    }

    throw new Error('Could not find MediaFire download link — file may be private or removed')
}

// ══════════════════════════════════════════════════════════════════════════════
//  MESSAGE CARDS  — consistent premium formatting for all states
// ══════════════════════════════════════════════════════════════════════════════

function cardSearching(query) {
    return fmt.box('🔍 SEARCHING', [
        `*${query}*`,
        `_Please wait..._`,
    ])
}

function cardFound(info) {
    const lines = [`✦ *${info.title}*`]
    if (info.author)   lines.push(`👤 ${info.author}`)
    if (info.album)    lines.push(`💿 ${info.album}`)
    if (info.duration) lines.push(`⏱ ${info.duration}`)
    if (info.quality)  lines.push(`🎧 ${info.quality}`)
    if (info.size)     lines.push(`📦 ${info.size}`)
    if (info.views)    lines.push(`👁 ${info.views}`)
    if (info.source)   lines.push(``, `_Source: ${info.source}_`)
    lines.push(``, `⏳ Downloading...`)
    return fmt.box('🎵 FOUND', lines)
}

function cardDownloading(label = 'media') {
    return fmt.box('⬇️ DOWNLOADING', [
        `⏳ Fetching *${label}*...`,
        `_This may take a few seconds_`,
    ])
}

function cardDone(title, source = '') {
    return fmt.box('✅ DONE', [
        `*${title}*`,
        source ? `_via ${source}_` : null,
    ].filter(Boolean))
}

function cardNotFound(query, suggestions = []) {
    const lines = [`Could not find: *${query}*`]
    if (suggestions.length) {
        lines.push(``, `💡 *Try these commands:*`, ...suggestions)
    }
    return fmt.box('❌ NOT FOUND', lines)
}

function cardError(msg, tip = '') {
    return fmt.box('❌ ERROR', [
        msg,
        tip ? `` : null,
        tip ? `💡 ${tip}` : null,
    ].filter(Boolean))
}

// ══════════════════════════════════════════════════════════════════════════════
//  MAIN DISPATCHER
// ══════════════════════════════════════════════════════════════════════════════

async function downloadMedia(sock, from, cmd, q, msg) {
    const p = config.prefix

    // ── PLAY / SONG / MUSIC ───────────────────────────────────────────────────
    if (['play', 'song', 'song2', 'music', 'mp3'].includes(cmd)) {
        await sock.sendMessage(from, { text: cardSearching(q) }, { quoted: msg })

        // ── Step 1: JioSaavn (best for music — real HQ MP3 links) ─────────────
        const saavn = await saavnSearch(q)
        if (saavn) {
            if (saavn.secs > MAX_MUSIC_SECS) {
                await sock.sendMessage(from, {
                    text: cardError(`*${saavn.title}* is ${saavn.duration} long — too long for a song`, 'Try a more specific search')
                }, { quoted: msg })
                return
            }
            await sock.sendMessage(from, { text: cardFound(saavn) }, { quoted: msg })
            try {
                const buf = await withRetry(() => toBuffer(saavn.dlUrl, { label: 'JioSaavn', timeoutMs: 60_000 }), 2)
                await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
                await fmt.done(sock, msg)
                return
            } catch {}
            // JioSaavn link expired — fall through silently
        }

        // ── Step 2: YouTube search + cobalt/ytdlp ─────────────────────────────
        await sock.sendMessage(from, {
            text: fmt.box('🔄 TRYING YOUTUBE', [`Searching YouTube for: *${q}*`])
        }, { quoted: msg })

        const yt = await ytSearch(q, { maxSecs: MAX_MUSIC_SECS })
        if (yt) {
            await sock.sendMessage(from, { text: cardFound({ ...yt, source: 'YouTube' }) }, { quoted: msg })
            try {
                const ytdlp = await hasYtdlp()
                let buf = null
                if (ytdlp) {
                    buf = await ytdlpDownload(yt.url, true)
                } else {
                    const dlUrl = await ytAudioUrl(yt.id)
                    if (dlUrl) buf = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 90_000 }), 2)
                }
                if (buf && validateMedia(buf, 'audio')) {
                    await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
                    await fmt.done(sock, msg)
                    return
                }
            } catch {}
        }

        // ── Step 3: Give up gracefully ────────────────────────────────────────
        await sock.sendMessage(from, {
            text: cardNotFound(q, [
                `_${p}play ${q}_`,
                `_${p}ytmp3_`,
                `_${p}spotify_`,
            ])
        }, { quoted: msg })
        return
    }

    // ── YTMP3  (YouTube → MP3 audio) ──────────────────────────────────────────
    if (['ytmp3', 'tomp3', 'toaudio', 'yta'].includes(cmd)) {
        if (!q) return sock.sendMessage(from, { text: fmt.usage('ytmp3', '<YouTube URL or search>') }, { quoted: msg })

        // If not a URL, try JioSaavn first
        if (!q.startsWith('http')) {
            const saavn = await saavnSearch(q)
            if (saavn) {
                await sock.sendMessage(from, { text: cardFound(saavn) }, { quoted: msg })
                try {
                    const buf = await toBuffer(saavn.dlUrl, { timeoutMs: 60_000 })
                    await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
                    await fmt.done(sock, msg)
                    return
                } catch {}
            }
        }

        await sock.sendMessage(from, { text: cardDownloading('YouTube audio') }, { quoted: msg })
        try {
            const ytdlp = await hasYtdlp()
            let buf = null
            if (ytdlp) {
                const url = q.startsWith('http') ? q : (await ytSearch(q, { maxSecs: 3600 }))?.url
                if (!url) throw new Error('Song not found on YouTube')
                buf = await ytdlpDownload(url, true)
            } else {
                const id = q.match(/(?:v=|youtu\.be\/)([A-Za-z0-9_-]{11})/)?.[1]
                    || (await ytSearch(q, { maxSecs: 3600 }))?.id
                if (!id) throw new Error('Cannot find video')
                const dlUrl = await ytAudioUrl(id)
                if (!dlUrl) throw new Error('No audio download source available')
                buf = await toBuffer(dlUrl, { timeoutMs: 90_000 })
            }
            if (!buf) throw new Error('Download produced empty file')
            await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
            await fmt.done(sock, msg)
        } catch (e) {
            await sock.sendMessage(from, { text: cardError(e.message, `Try: ${p}ytmp3 <YouTube URL>`) }, { quoted: msg })
        }
        return
    }

    // ── YTMP4 / VIDEO  (YouTube → MP4 video) ──────────────────────────────────
    if (['ytmp4', 'yt', 'tovideo', 'video', 'ytv', 'download'].includes(cmd)) {
        if (!q) return sock.sendMessage(from, { text: fmt.usage(cmd, '<YouTube URL or search>') }, { quoted: msg })

        let url = q.trim(), title = q, duration = ''

        if (!url.startsWith('http')) {
            await sock.sendMessage(from, { text: cardSearching(q) }, { quoted: msg })
            const r = await ytSearch(q, { maxSecs: MAX_VIDEO_SECS })
            if (!r) return sock.sendMessage(from, { text: cardNotFound(q, [`_${p}ytmp4_`]) }, { quoted: msg })
            url = r.url; title = r.title; duration = r.duration
            await sock.sendMessage(from, {
                text: cardFound({ title, author: r.author, duration, source: 'YouTube' })
            }, { quoted: msg })
        } else {
            await sock.sendMessage(from, { text: cardDownloading('YouTube video') }, { quoted: msg })
        }

        try {
            const ytdlp = await hasYtdlp()
            let buf = null
            if (ytdlp) {
                buf = await ytdlpDownload(url, false)
            } else {
                const dlUrl = await cobaltFetch(url, false)
                buf = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 120_000 }), 2)
            }
            if (!buf) throw new Error('No video data received')
            await sock.sendMessage(from, {
                video:   buf,
                mimetype: 'video/mp4',
                caption:  fmt.box('🎬 VIDEO', [`✦ *${title}*`, duration ? `⏱ ${duration}` : null].filter(Boolean)),
            }, { quoted: msg })
            await fmt.done(sock, msg)
        } catch (e) {
            await sock.sendMessage(from, { text: cardError(e.message, `Paste the YouTube link directly: ${p}ytmp4 <URL>`) }, { quoted: msg })
        }
        return
    }

    // ── TIKTOK  (video + audio via TikWM API) ─────────────────────────────────
    if (['tiktok', 'tt', 'tkvid'].includes(cmd)) {
        if (!q || !q.includes('tiktok'))
            return sock.sendMessage(from, { text: fmt.usage('tiktok', '<TikTok URL>') }, { quoted: msg })

        await sock.sendMessage(from, { text: cardDownloading('TikTok') }, { quoted: msg })
        try {
            // ── TikWM first (no watermark) ────────────────────────────────────
            const info = await tikwmFetch(q, false)
            if (info?.videoUrl) {
                const buf = await withRetry(() => toBuffer(info.videoUrl, { timeoutMs: 60_000 }), 2)
                await sock.sendMessage(from, {
                    video:    buf,
                    mimetype: 'video/mp4',
                    caption:  fmt.box('🎵 TIKTOK', [
                        info.title  ? `✦ *${info.title}*`   : null,
                        info.author ? `👤 ${info.author}`   : null,
                        info.duration ? `⏱ ${info.duration}` : null,
                    ].filter(Boolean)),
                }, { quoted: msg })
                await fmt.done(sock, msg)
                return
            }

            // ── Cobalt fallback ───────────────────────────────────────────────
            const dlUrl = await cobaltFetch(q, false)
            const buf   = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 60_000 }), 2)
            await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '🎵 TikTok' }, { quoted: msg })
            await fmt.done(sock, msg)
        } catch (e) {
            // ── yt-dlp last resort ────────────────────────────────────────────
            try {
                const buf = await ytdlpDownload(q, false)
                await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '🎵 TikTok' }, { quoted: msg })
                await fmt.done(sock, msg)
            } catch {
                await sock.sendMessage(from, { text: cardError(e.message, 'Paste the full TikTok share link') }, { quoted: msg })
            }
        }
        return
    }

    // ── TIKTOK AUDIO  (music only) ────────────────────────────────────────────
    if (['tiktokaudio', 'tkaudio', 'ttaudio'].includes(cmd)) {
        if (!q || !q.includes('tiktok'))
            return sock.sendMessage(from, { text: fmt.usage('tiktokaudio', '<TikTok URL>') }, { quoted: msg })

        await sock.sendMessage(from, { text: cardDownloading('TikTok audio') }, { quoted: msg })
        try {
            const info = await tikwmFetch(q, true)
            if (info?.audioUrl) {
                const buf = await toBuffer(info.audioUrl, { timeoutMs: 45_000 })
                await sock.sendMessage(from, {
                    audio: buf, mimetype: 'audio/mpeg', pttAudio: false,
                }, { quoted: msg })
                await fmt.done(sock, msg)
                return
            }
            // Fallback: cobalt audio
            const dlUrl = await cobaltFetch(q, true)
            const buf   = await toBuffer(dlUrl, { timeoutMs: 60_000 })
            await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
            await fmt.done(sock, msg)
        } catch (e) {
            await sock.sendMessage(from, { text: cardError(e.message) }, { quoted: msg })
        }
        return
    }

    // ── INSTAGRAM ─────────────────────────────────────────────────────────────
    if (['ig', 'instagram', 'insta'].includes(cmd)) {
        if (!q || !q.match(/instagram\.com/i))
            return sock.sendMessage(from, { text: fmt.usage('ig', '<Instagram URL>') }, { quoted: msg })

        await sock.sendMessage(from, { text: cardDownloading('Instagram') }, { quoted: msg })
        try {
            const dlUrl = await cobaltFetch(q, false)
            const buf   = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 90_000 }), 2)
            try {
                await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '📸 Instagram' }, { quoted: msg })
            } catch {
                await sock.sendMessage(from, { image: buf, caption: '📸 Instagram' }, { quoted: msg })
            }
            await fmt.done(sock, msg)
        } catch {
            try {
                const buf = await ytdlpDownload(q, false)
                try {
                    await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '📸 Instagram' }, { quoted: msg })
                } catch {
                    await sock.sendMessage(from, { image: buf, caption: '📸 Instagram' }, { quoted: msg })
                }
                await fmt.done(sock, msg)
            } catch (e) {
                await sock.sendMessage(from, { text: cardError(e.message, 'Only public posts can be downloaded') }, { quoted: msg })
            }
        }
        return
    }

    // ── TWITTER / X ───────────────────────────────────────────────────────────
    if (['twitter', 'x', 'tweet'].includes(cmd)) {
        if (!q || !q.match(/twitter\.com|x\.com/i))
            return sock.sendMessage(from, { text: fmt.usage('twitter', '<Twitter/X URL>') }, { quoted: msg })

        await sock.sendMessage(from, { text: cardDownloading('Twitter/X') }, { quoted: msg })
        try {
            const dlUrl = await cobaltFetch(q, false)
            const buf   = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 90_000 }), 2)
            try {
                await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '🐦 Twitter/X' }, { quoted: msg })
            } catch {
                await sock.sendMessage(from, { image: buf, caption: '🐦 Twitter/X' }, { quoted: msg })
            }
            await fmt.done(sock, msg)
        } catch {
            try {
                const buf = await ytdlpDownload(q, false)
                await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '🐦 Twitter/X' }, { quoted: msg })
                await fmt.done(sock, msg)
            } catch (e) {
                await sock.sendMessage(from, { text: cardError(e.message) }, { quoted: msg })
            }
        }
        return
    }

    // ── FACEBOOK ──────────────────────────────────────────────────────────────
    if (['facebook', 'fb', 'fbvid'].includes(cmd)) {
        if (!q || !q.match(/facebook\.com|fb\.watch/i))
            return sock.sendMessage(from, { text: fmt.usage('facebook', '<Facebook URL>') }, { quoted: msg })

        await sock.sendMessage(from, { text: cardDownloading('Facebook') }, { quoted: msg })
        try {
            const dlUrl = await cobaltFetch(q, false)
            const buf   = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 90_000 }), 2)
            await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '📘 Facebook' }, { quoted: msg })
            await fmt.done(sock, msg)
        } catch {
            try {
                const buf = await ytdlpDownload(q, false)
                await sock.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption: '📘 Facebook' }, { quoted: msg })
                await fmt.done(sock, msg)
            } catch (e) {
                await sock.sendMessage(from, { text: cardError(e.message, 'Only public videos can be downloaded') }, { quoted: msg })
            }
        }
        return
    }

    // ── SPOTIFY ───────────────────────────────────────────────────────────────
    if (['spotify', 'sp', 'spdl'].includes(cmd)) {
        if (!q || !q.includes('spotify'))
            return sock.sendMessage(from, { text: fmt.usage('spotify', '<Spotify track URL>') }, { quoted: msg })

        await sock.sendMessage(from, {
            text: fmt.box('🟢 SPOTIFY', [`🔍 Fetching track info...`])
        }, { quoted: msg })

        try {
            const info = await spotifyInfo(q)
            if (!info?.searchQuery) throw new Error('Could not read Spotify track info')

            await sock.sendMessage(from, {
                text: fmt.box('🔍 SEARCHING', [`Finding: *${info.title || info.searchQuery}*`])
            }, { quoted: msg })

            // ── Try JioSaavn match first ──────────────────────────────────────
            const saavn = await saavnSearch(info.searchQuery)
            if (saavn) {
                await sock.sendMessage(from, { text: cardFound({ ...saavn, source: 'Spotify → JioSaavn' }) }, { quoted: msg })
                try {
                    const buf = await withRetry(() => toBuffer(saavn.dlUrl, { timeoutMs: 60_000 }), 2)
                    await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
                    await fmt.done(sock, msg)
                    return
                } catch {}
            }

            // ── YouTube fallback ──────────────────────────────────────────────
            const yt = await ytSearch(info.searchQuery, { maxSecs: MAX_MUSIC_SECS })
            if (!yt) throw new Error(`Could not find: *${info.searchQuery}*`)

            await sock.sendMessage(from, { text: cardFound({ ...yt, source: 'Spotify → YouTube' }) }, { quoted: msg })

            const ytdlp = await hasYtdlp()
            let buf = null
            if (ytdlp) {
                buf = await ytdlpDownload(yt.url, true)
            } else {
                const dlUrl = await ytAudioUrl(yt.id)
                if (!dlUrl) throw new Error('No audio download source found')
                buf = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 90_000 }), 2)
            }

            await sock.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg', pttAudio: false }, { quoted: msg })
            await fmt.done(sock, msg)

        } catch (e) {
            await sock.sendMessage(from, {
                text: cardError(e.message, `Try: ${p}play <song name and artist>`)
            }, { quoted: msg })
        }
        return
    }

    // ── MEDIAFIRE ─────────────────────────────────────────────────────────────
    if (['mediafire', 'mf', 'mfdl'].includes(cmd)) {
        if (!q || !q.includes('mediafire'))
            return sock.sendMessage(from, { text: fmt.usage('mediafire', '<MediaFire URL>') }, { quoted: msg })

        await sock.sendMessage(from, {
            text: fmt.box('📁 MEDIAFIRE', [`🔗 Extracting download link...`])
        }, { quoted: msg })

        try {
            const dlUrl = await withRetry(() => mediaFireLink(q), 2, 2000)
            const filename = dlUrl.split('/').pop()?.split('?')[0] || 'file'

            await sock.sendMessage(from, {
                text: fmt.box('📁 MEDIAFIRE', [
                    `📄 *${decodeURIComponent(filename)}*`,
                    `⏳ Downloading...`,
                ])
            }, { quoted: msg })

            const buf = await withRetry(() => toBuffer(dlUrl, { timeoutMs: 120_000 }), 2)

            // Determine MIME type from extension
            const ext  = filename.split('.').pop()?.toLowerCase() || ''
            const mime = {
                mp3: 'audio/mpeg', mp4: 'video/mp4', pdf: 'application/pdf',
                zip: 'application/zip', rar: 'application/x-rar-compressed',
                apk: 'application/vnd.android.package-archive',
            }[ext] || 'application/octet-stream'

            if (mime.startsWith('audio/')) {
                await sock.sendMessage(from, { audio: buf, mimetype: mime, pttAudio: false }, { quoted: msg })
            } else if (mime.startsWith('video/')) {
                await sock.sendMessage(from, { video: buf, mimetype: mime, caption: `📁 ${filename}` }, { quoted: msg })
            } else {
                await sock.sendMessage(from, {
                    document: buf, mimetype: mime, fileName: filename,
                    caption: fmt.box('📁 DOWNLOAD', [`✅ *${filename}*`, `📦 ${fmtSize(buf.length)}`]),
                }, { quoted: msg })
            }
            await fmt.done(sock, msg)
        } catch (e) {
            await sock.sendMessage(from, {
                text: cardError(e.message, 'Ensure the file is public and the URL is complete')
            }, { quoted: msg })
        }
        return
    }
}

module.exports = { downloadMedia }
