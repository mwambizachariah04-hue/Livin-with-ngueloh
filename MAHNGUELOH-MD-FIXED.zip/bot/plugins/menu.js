'use strict'
const config = require('../config')
const os     = require('os')
const fs     = require('fs')
const path   = require('path')
const fmt    = require('../lib/format')

// ─────────────────────────────────────────────────────────────────────────────

function getRam() {
    const t = os.totalmem(), u = t - os.freemem()
    const pct    = Math.round(u / t * 100)
    const filled = Math.round(pct / 10)
    const bar    = '█'.repeat(filled) + '░'.repeat(10 - filled)
    return { pct, usedMB: Math.round(u / 1024 / 1024), totalGB: (t / 1024 / 1024 / 1024).toFixed(1), bar }
}

function getTime() {
    return new Date().toLocaleString('en-KE', {
        timeZone: config.timezone || 'Africa/Nairobi',
        weekday:  'short',
        hour:     '2-digit',
        minute:   '2-digit',
        hour12:   true,
    })
}

async function sendMenu(sock, from, sender, msg) {
    const p   = config.prefix
    const ram = getRam()
    const uptime    = process.uptime()
    const uptimeStr = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`

    await fmt.react(sock, msg, '⚡')

    // ── Status header ─────────────────────────────────────────────────────────
    const header = [
        `╔${'═'.repeat(44)}╗`,
        `║  ⚡  *${config.botName}*`,
        `╠${'═'.repeat(44)}╣`,
        `║  👑  Owner   »  *${config.ownerName}*`,
        `║  🔖  Prefix  »  *[ ${p} ]*`,
        `║  🌐  Mode    »  *${(config.mode || 'public').toUpperCase()}*`,
        `║  🧠  AI      »  ${config.aiEnabled !== false ? '*✅ ONLINE*' : '*❌ OFF*'}`,
        `║  🏷️   Version »  *v${config.version || '3.1.0'}*`,
        `║  🕐  Time    »  *${getTime()}*`,
        `║  ⏱️   Uptime  »  *${uptimeStr}*`,
        `║  💾  RAM     »  *${ram.usedMB}MB / ${ram.totalGB}GB*  [${ram.bar}] ${ram.pct}%`,
        `╚${'═'.repeat(44)}╝`,
    ].join('\n')

    // ── Downloads ─────────────────────────────────────────────────────────────
    const dlMenu = fmt.box('📥 DOWNLOADS', [
        fmt.divider('🎵 Music'),
        `◈ ${p}play`,
        `◈ ${p}song`,
        `◈ ${p}ytmp3`,
        `◈ ${p}spotify`,
        fmt.divider('🎬 Video'),
        `◈ ${p}ytmp4`,
        `◈ ${p}video`,
        fmt.divider('📱 Social Media'),
        `◈ ${p}tiktok`,
        `◈ ${p}tiktokaudio`,
        `◈ ${p}ig`,
        `◈ ${p}twitter`,
        `◈ ${p}facebook`,
        fmt.divider('📁 Files'),
        `◈ ${p}mediafire`,
    ])

    // ── Group commands ────────────────────────────────────────────────────────
    const grpMenu = fmt.box('👥 GROUP COMMANDS', [
        fmt.divider('Members'),
        `◈ ${p}kick`,
        `◈ ${p}add`,
        `◈ ${p}ban`,
        `◈ ${p}unban`,
        `◈ ${p}promote`,
        `◈ ${p}demote`,
        `◈ ${p}mute`,
        `◈ ${p}unmute`,
        `◈ ${p}kickall`,
        fmt.divider('Tagging'),
        `◈ ${p}tagall`,
        `◈ ${p}tagadmin`,
        `◈ ${p}admins`,
        `◈ ${p}hidetag`,
        `◈ ${p}poll`,
        fmt.divider('Info'),
        `◈ ${p}invite`,
        `◈ ${p}link`,
        `◈ ${p}totalmembers`,
        `◈ ${p}getsettings`,
        fmt.divider('Protection'),
        `◈ ${p}antilink`,
        `◈ ${p}antispam`,
        `◈ ${p}antisticker`,
        `◈ ${p}antibug`,
        `◈ ${p}antivoicenote`,
        `◈ ${p}antiremove`,
        `◈ ${p}welcome`,
        `◈ ${p}goodbye`,
        fmt.divider('Settings'),
        `◈ ${p}setgroupname`,
        `◈ ${p}setdesc`,
        `◈ ${p}resetlink`,
        `◈ ${p}setppgroup`,
    ])

    // ── AI ────────────────────────────────────────────────────────────────────
    const aiMenu = fmt.box('🧠 AI COMMANDS', [
        fmt.divider('General'),
        `◈ ${p}ai`,
        `◈ ${p}gpt`,
        `◈ ${p}gemini`,
        `◈ ${p}deepseek`,
        fmt.divider('Creative'),
        `◈ ${p}analyze`,
        `◈ ${p}code`,
        `◈ ${p}story`,
        `◈ ${p}recipe`,
        `◈ ${p}summarize`,
        `◈ ${p}teach`,
        `◈ ${p}generate`,
        `◈ ${p}translate`,
    ])

    // ── Tools ─────────────────────────────────────────────────────────────────
    const toolMenu = fmt.box('🔧 TOOLS', [
        fmt.divider('Media'),
        `◈ ${p}sticker`,
        `◈ ${p}toimage`,
        `◈ ${p}remini`,
        `◈ ${p}wallpaper`,
        `◈ ${p}vv`,
        `◈ ${p}reveal`,
        fmt.divider('Utility'),
        `◈ ${p}qrcode`,
        `◈ ${p}tinyurl`,
        `◈ ${p}calculate`,
        `◈ ${p}genpass`,
        `◈ ${p}fancy`,
        `◈ ${p}fliptext`,
        `◈ ${p}weather`,
        `◈ ${p}define`,
        `◈ ${p}getpp`,
        `◈ ${p}getabout`,
        `◈ ${p}device`,
    ])

    // ── Search ────────────────────────────────────────────────────────────────
    const searchMenu = fmt.box('🔍 SEARCH', [
        `◈ ${p}lyrics`,
        `◈ ${p}imdb`,
        `◈ ${p}yts`,
        `◈ ${p}gsmarena`,
    ])

    // ── Fun ───────────────────────────────────────────────────────────────────
    const funMenu = fmt.box('🎮 FUN & GAMES', [
        `◈ ${p}fact`,
        `◈ ${p}jokes`,
        `◈ ${p}memes`,
        `◈ ${p}quotes`,
        `◈ ${p}trivia`,
        `◈ ${p}truth`,
        `◈ ${p}dare`,
        `◈ ${p}truthordare`,
        `◈ ${p}truthdetector`,
        `◈ ${p}emojimix`,
    ])

    // ── Religion ──────────────────────────────────────────────────────────────
    const relMenu = fmt.box('🙏 RELIGION', [
        `◈ ${p}bible`,
        `◈ ${p}quran`,
    ])

    // ── Sports ────────────────────────────────────────────────────────────────
    const sportsMenu = fmt.box('⚽ SPORTS', [
        fmt.divider('Football'),
        `◈ ${p}eplmatches`,
        `◈ ${p}eplstandings`,
        `◈ ${p}laligamatches`,
        `◈ ${p}laligastandings`,
        `◈ ${p}bundesligamatches`,
        `◈ ${p}serieamatches`,
        `◈ ${p}serieastandings`,
        `◈ ${p}clmatches`,
        `◈ ${p}clstandings`,
        fmt.divider('Wrestling'),
        `◈ ${p}wrestlingevents`,
        `◈ ${p}wwenews`,
        `◈ ${p}wweschedule`,
    ])

    // ── Custom commands ───────────────────────────────────────────────────────
    const customMenu = fmt.box('📌 CUSTOM COMMANDS', [
        `◈ ${p}addcmd`,
        `◈ ${p}editcmd`,
        `◈ ${p}delcmd`,
        `◈ ${p}listcmd`,
        `◈ ${p}cmdinfo`,
    ])

    // ── Owner panel ───────────────────────────────────────────────────────────
    const ownerMenu = fmt.box('👑 OWNER PANEL', [
        fmt.divider('Bot Control'),
        `◈ ${p}mode`,
        `◈ ${p}restart`,
        `◈ ${p}setbotname`,
        `◈ ${p}setownername`,
        `◈ ${p}setprefix`,
        `◈ ${p}setbio`,
        `◈ ${p}setprofilepic`,
        fmt.divider('Auto Features'),
        `◈ ${p}alwaysonline`,
        `◈ ${p}autoread`,
        `◈ ${p}anticall`,
        `◈ ${p}autoreact`,
        `◈ ${p}autoviewstatus`,
        `◈ ${p}autoreactstatus`,
        `◈ ${p}chatbot`,
        fmt.divider('Users'),
        `◈ ${p}block`,
        `◈ ${p}unblock`,
        `◈ ${p}addsudo`,
        `◈ ${p}delsudo`,
        `◈ ${p}warn`,
        `◈ ${p}resetwarn`,
        `◈ ${p}listwarn`,
        fmt.divider('Utilities'),
        `◈ ${p}delete`,
        `◈ ${p}broadcast`,
        `◈ ${p}join`,
        `◈ ${p}leave`,
        `◈ ${p}hostip`,
        `◈ ${p}disk`,
        `◈ ${p}allgroups`,
    ])

    // ── General ───────────────────────────────────────────────────────────────
    const genMenu = fmt.box('ℹ️ GENERAL', [
        `◈ ${p}menu`,
        `◈ ${p}help`,
        `◈ ${p}ping`,
        `◈ ${p}runtime`,
        `◈ ${p}botstatus`,
        `◈ ${p}owner`,
        `◈ ${p}repo`,
        `◈ ${p}time`,
        `◈ ${p}userid`,
        `◈ ${p}feedback`,
    ])

    const footer = [
        ``,
        `╔${'═'.repeat(44)}╗`,
        `║  🤖  *${config.botName}*  |  Prefix: *${p}*`,
        `║  Type *${p}menu* anytime for help`,
        `╚${'═'.repeat(44)}╝`,
    ].join('\n')

    const fullText = [
        header, '', dlMenu, grpMenu, aiMenu, toolMenu,
        searchMenu, funMenu, relMenu, sportsMenu,
        customMenu, ownerMenu, genMenu, footer,
    ].join('\n\n')

    const bannerPath = path.join(__dirname, '../assets/banner.png')
    if (fs.existsSync(bannerPath)) {
        await sock.sendMessage(from, {
            image:   fs.readFileSync(bannerPath),
            caption: fullText,
        }, { quoted: msg })
    } else {
        await sock.sendMessage(from, { text: fullText }, { quoted: msg })
    }
}

module.exports = { sendMenu }
